CREATE MATERIALIZED VIEW vasopressordurations AS WITH io_cv AS (
         SELECT inputevents_cv.icustay_id,
            inputevents_cv.charttime,
            inputevents_cv.itemid,
            inputevents_cv.stopped,
                CASE
                    WHEN (inputevents_cv.itemid = ANY (ARRAY[42273, 42802])) THEN inputevents_cv.amount
                    ELSE inputevents_cv.rate
                END AS rate,
                CASE
                    WHEN (inputevents_cv.itemid = ANY (ARRAY[42273, 42802])) THEN inputevents_cv.rate
                    ELSE inputevents_cv.amount
                END AS amount
           FROM mimiciii.inputevents_cv
          WHERE (inputevents_cv.itemid = ANY (ARRAY[30047, 30120, 30044, 30119, 30309, 30127, 30128, 30051, 30043, 30307, 30042, 30306, 30125, 42273, 42802]))
        ), io_mv AS (
         SELECT io.icustay_id,
            io.linkorderid,
            io.starttime,
            io.endtime
           FROM mimiciii.inputevents_mv io
          WHERE ((io.itemid = ANY (ARRAY[221906, 221289, 221749, 222315, 221662, 221653, 221986])) AND ((io.statusdescription)::text <> 'Rewritten'::text))
        ), vasocv1 AS (
         SELECT io_cv.icustay_id,
            io_cv.charttime,
            io_cv.itemid,
            1 AS vaso,
            max(
                CASE
                    WHEN ((io_cv.stopped)::text = ANY ((ARRAY['Stopped'::character varying, 'D/C''d'::character varying])::text[])) THEN 1
                    ELSE 0
                END) AS vaso_stopped,
            max(
                CASE
                    WHEN (io_cv.rate IS NOT NULL) THEN 1
                    ELSE 0
                END) AS vaso_null,
            max(io_cv.rate) AS vaso_rate,
            max(io_cv.amount) AS vaso_amount
           FROM io_cv
          GROUP BY io_cv.icustay_id, io_cv.charttime, io_cv.itemid
        ), vasocv2 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.itemid,
            v.vaso,
            v.vaso_stopped,
            v.vaso_null,
            v.vaso_rate,
            v.vaso_amount,
            sum(v.vaso_null) OVER (PARTITION BY v.icustay_id, v.itemid ORDER BY v.charttime) AS vaso_partition
           FROM vasocv1 v
        ), vasocv3 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.itemid,
            v.vaso,
            v.vaso_stopped,
            v.vaso_null,
            v.vaso_rate,
            v.vaso_amount,
            v.vaso_partition,
            first_value(v.vaso_rate) OVER (PARTITION BY v.icustay_id, v.itemid, v.vaso_partition ORDER BY v.charttime) AS vaso_prevrate_ifnull
           FROM vasocv2 v
        ), vasocv4 AS (
         SELECT vasocv3.icustay_id,
            vasocv3.charttime,
            vasocv3.itemid,
            vasocv3.vaso,
            vasocv3.vaso_rate,
            vasocv3.vaso_amount,
            vasocv3.vaso_stopped,
            vasocv3.vaso_prevrate_ifnull,
                CASE
                    WHEN (vasocv3.vaso = 0) THEN NULL::integer
                    WHEN ((vasocv3.vaso_rate > (0)::double precision) AND (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.itemid, vasocv3.vaso, vasocv3.vaso_null ORDER BY vasocv3.charttime) IS NULL)) THEN 1
                    WHEN ((vasocv3.vaso_rate = (0)::double precision) AND (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.itemid, vasocv3.vaso ORDER BY vasocv3.charttime) = (0)::double precision)) THEN 0
                    WHEN ((vasocv3.vaso_prevrate_ifnull = (0)::double precision) AND (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.itemid, vasocv3.vaso ORDER BY vasocv3.charttime) = (0)::double precision)) THEN 0
                    WHEN (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.itemid, vasocv3.vaso ORDER BY vasocv3.charttime) = (0)::double precision) THEN 1
                    WHEN (lag(vasocv3.vaso_stopped, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.itemid, vasocv3.vaso ORDER BY vasocv3.charttime) = 1) THEN 1
                    ELSE NULL::integer
                END AS vaso_start
           FROM vasocv3
        ), vasocv5 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.itemid,
            v.vaso,
            v.vaso_rate,
            v.vaso_amount,
            v.vaso_stopped,
            v.vaso_prevrate_ifnull,
            v.vaso_start,
            sum(v.vaso_start) OVER (PARTITION BY v.icustay_id, v.itemid, v.vaso ORDER BY v.charttime) AS vaso_first
           FROM vasocv4 v
        ), vasocv6 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.itemid,
            v.vaso,
            v.vaso_rate,
            v.vaso_amount,
            v.vaso_stopped,
            v.vaso_prevrate_ifnull,
            v.vaso_start,
            v.vaso_first,
                CASE
                    WHEN (v.vaso = 0) THEN NULL::bigint
                    WHEN (v.vaso_stopped = 1) THEN v.vaso_first
                    WHEN (v.vaso_rate = (0)::double precision) THEN v.vaso_first
                    WHEN (lead(v.charttime, 1) OVER (PARTITION BY v.icustay_id, v.itemid, v.vaso ORDER BY v.charttime) IS NULL) THEN v.vaso_first
                    ELSE NULL::bigint
                END AS vaso_stop
           FROM vasocv5 v
        ), vasocv AS (
         SELECT vasocv6.icustay_id,
            vasocv6.itemid,
            min(
                CASE
                    WHEN (vasocv6.vaso_rate IS NOT NULL) THEN vasocv6.charttime
                    ELSE NULL::timestamp without time zone
                END) AS starttime,
            min(
                CASE
                    WHEN (vasocv6.vaso_first = vasocv6.vaso_stop) THEN vasocv6.charttime
                    ELSE NULL::timestamp without time zone
                END) AS endtime
           FROM vasocv6
          WHERE ((vasocv6.vaso_first IS NOT NULL) AND (vasocv6.vaso_first <> 0) AND (vasocv6.icustay_id IS NOT NULL))
          GROUP BY vasocv6.icustay_id, vasocv6.itemid, vasocv6.vaso_first
         HAVING ((min(vasocv6.charttime) <> min(
                CASE
                    WHEN (vasocv6.vaso_first = vasocv6.vaso_stop) THEN vasocv6.charttime
                    ELSE NULL::timestamp without time zone
                END)) AND (max(vasocv6.vaso_rate) > (0)::double precision))
        ), vasocv_grp AS (
         SELECT s1.icustay_id,
            s1.starttime,
            min(t1.endtime) AS endtime
           FROM (vasocv s1
             JOIN vasocv t1 ON (((s1.icustay_id = t1.icustay_id) AND (s1.starttime <= t1.endtime) AND (NOT (EXISTS ( SELECT t2.icustay_id,
                    t2.itemid,
                    t2.starttime,
                    t2.endtime
                   FROM vasocv t2
                  WHERE ((t1.icustay_id = t2.icustay_id) AND (t1.endtime >= t2.starttime) AND (t1.endtime < t2.endtime))))))))
          WHERE (NOT (EXISTS ( SELECT s2.icustay_id,
                    s2.itemid,
                    s2.starttime,
                    s2.endtime
                   FROM vasocv s2
                  WHERE ((s1.icustay_id = s2.icustay_id) AND (s1.starttime > s2.starttime) AND (s1.starttime <= s2.endtime)))))
          GROUP BY s1.icustay_id, s1.starttime
          ORDER BY s1.icustay_id, s1.starttime
        ), vasomv AS (
         SELECT io_mv.icustay_id,
            io_mv.linkorderid,
            min(io_mv.starttime) AS starttime,
            max(io_mv.endtime) AS endtime
           FROM io_mv
          GROUP BY io_mv.icustay_id, io_mv.linkorderid
        ), vasomv_grp AS (
         SELECT s1.icustay_id,
            s1.starttime,
            min(t1.endtime) AS endtime
           FROM (vasomv s1
             JOIN vasomv t1 ON (((s1.icustay_id = t1.icustay_id) AND (s1.starttime <= t1.endtime) AND (NOT (EXISTS ( SELECT t2.icustay_id,
                    t2.linkorderid,
                    t2.starttime,
                    t2.endtime
                   FROM vasomv t2
                  WHERE ((t1.icustay_id = t2.icustay_id) AND (t1.endtime >= t2.starttime) AND (t1.endtime < t2.endtime))))))))
          WHERE (NOT (EXISTS ( SELECT s2.icustay_id,
                    s2.linkorderid,
                    s2.starttime,
                    s2.endtime
                   FROM vasomv s2
                  WHERE ((s1.icustay_id = s2.icustay_id) AND (s1.starttime > s2.starttime) AND (s1.starttime <= s2.endtime)))))
          GROUP BY s1.icustay_id, s1.starttime
          ORDER BY s1.icustay_id, s1.starttime
        )
 SELECT vasocv_grp.icustay_id,
    row_number() OVER (PARTITION BY vasocv_grp.icustay_id ORDER BY vasocv_grp.starttime) AS vasonum,
    vasocv_grp.starttime,
    vasocv_grp.endtime,
    ((date_part('epoch'::text, (vasocv_grp.endtime - vasocv_grp.starttime)) / (60)::double precision) / (60)::double precision) AS duration_hours
   FROM vasocv_grp
UNION
 SELECT vasomv_grp.icustay_id,
    row_number() OVER (PARTITION BY vasomv_grp.icustay_id ORDER BY vasomv_grp.starttime) AS vasonum,
    vasomv_grp.starttime,
    vasomv_grp.endtime,
    ((date_part('epoch'::text, (vasomv_grp.endtime - vasomv_grp.starttime)) / (60)::double precision) / (60)::double precision) AS duration_hours
   FROM vasomv_grp
  ORDER BY 1, 2;

