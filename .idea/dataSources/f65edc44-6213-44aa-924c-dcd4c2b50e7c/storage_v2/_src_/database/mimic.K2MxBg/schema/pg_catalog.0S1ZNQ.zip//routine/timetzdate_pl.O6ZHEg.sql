create function timetzdate_pl(time with time zone, date) returns timestamp with time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select ($2 + $1)
$$;
