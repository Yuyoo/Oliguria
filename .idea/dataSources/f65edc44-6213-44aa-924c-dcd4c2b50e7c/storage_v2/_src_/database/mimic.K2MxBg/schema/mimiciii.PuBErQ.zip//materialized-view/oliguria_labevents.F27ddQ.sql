CREATE MATERIALIZED VIEW oliguria_labevents AS SELECT og.subject_id,
    og.hadm_id,
    og.icustay_id,
    le.charttime,
    max(
        CASE
            WHEN ((le.itemid = 50821) AND (le.valuenum > (0)::double precision) AND (le.valuenum < (800)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS po2,
    max(
        CASE
            WHEN ((le.itemid = 50818) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS pco2,
    max(
        CASE
            WHEN ((le.itemid = 50820) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS arterialph,
    max(
        CASE
            WHEN ((le.itemid = 50822) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS potassium,
    max(
        CASE
            WHEN ((le.itemid = 50808) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS calcium,
    max(
        CASE
            WHEN ((le.itemid = 50824) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS sodium,
    max(
        CASE
            WHEN ((le.itemid = 50806) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS chloride,
    max(
        CASE
            WHEN ((le.itemid = 50809) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS glucose,
    max(
        CASE
            WHEN ((le.itemid = 50882) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS bicarbonate,
    max(
        CASE
            WHEN ((le.itemid = 50802) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS be,
    max(
        CASE
            WHEN ((le.itemid = 51301) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS arterialwbc,
    max(
        CASE
            WHEN ((le.itemid = 51279) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS arterialrbc,
    max(
        CASE
            WHEN ((le.itemid = 51265) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS plt,
    max(
        CASE
            WHEN ((le.itemid = 50889) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS crp,
    max(
        CASE
            WHEN ((le.itemid = 50813) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS lactate,
    max(
        CASE
            WHEN ((le.itemid = 50861) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS alt,
    max(
        CASE
            WHEN ((le.itemid = 50878) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS ast,
    max(
        CASE
            WHEN ((le.itemid = 50912) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS creatinine,
    max(
        CASE
            WHEN ((le.itemid = 51006) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS bun,
    max(
        CASE
            WHEN ((le.itemid = 50867) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS amylase,
    max(
        CASE
            WHEN ((le.itemid = 50956) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS lipase,
    max(
        CASE
            WHEN ((le.itemid = 51094) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urine_ph,
    max(
        CASE
            WHEN ((le.itemid = 51516) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urine_wbc,
    max(
        CASE
            WHEN ((le.itemid = 51492) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urine_protein,
    max(
        CASE
            WHEN ((le.itemid = 51478) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urine_glucose,
    max(
        CASE
            WHEN ((le.itemid = 51464) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urine_bilirubin,
    max(
        CASE
            WHEN ((le.itemid = 51484) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urine_ketone,
    max(
        CASE
            WHEN ((le.itemid = 51493) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urine_rbc,
    max(
        CASE
            WHEN ((le.itemid = 51498) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS specificgravity,
    max(
        CASE
            WHEN ((le.itemid = 51514) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS urobilinogen,
    max((
        CASE
            WHEN (le.itemid = 51466) THEN le.value
            ELSE NULL::character varying
        END)::text) AS urine_blood,
    max((
        CASE
            WHEN (le.itemid = 51508) THEN le.value
            ELSE NULL::character varying
        END)::text) AS urine_color,
    max(
        CASE
            WHEN ((le.itemid = 51275) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS aptt,
    max(
        CASE
            WHEN ((le.itemid = 51274) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS pt,
    max(
        CASE
            WHEN ((le.itemid = 51237) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS inr,
    max(
        CASE
            WHEN ((le.itemid = 51196) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS d_dimer,
    max(
        CASE
            WHEN ((le.itemid = 51214) AND (le.valuenum > (0)::double precision)) THEN le.valuenum
            ELSE NULL::double precision
        END) AS fib
   FROM (mimiciii.oliguria og
     LEFT JOIN mimiciii.labevents le ON (((og.subject_id = le.subject_id) AND (og.hadm_id = le.hadm_id) AND ((le.charttime >= (og.intime - '06:00:00'::interval hour)) AND (le.charttime <= og.uo_charttime2)))))
  WHERE (le.itemid = ANY (ARRAY[50821, 50818, 50820, 50822, 50808, 50824, 50806, 50809, 50882, 50802, 51301, 51279, 51265, 50889, 50813, 50861, 50878, 50912, 51006, 50867, 50956, 51094, 51516, 51492, 51478, 51464, 51484, 51493, 51498, 51514, 51466, 51508, 51275, 51274, 51237, 51196, 51214]))
  GROUP BY og.subject_id, og.hadm_id, og.icustay_id, le.charttime;

