CREATE MATERIALIZED VIEW icustay_detail AS SELECT ie.subject_id,
    ie.hadm_id,
    ie.icustay_id,
    pat.gender,
    adm.admittime,
    adm.dischtime,
    round(((date_part('epoch'::text, (adm.dischtime - adm.admittime)) / (((60 * 60) * 24))::double precision))::numeric, 4) AS los_hospital,
    round(((date_part('epoch'::text, (adm.admittime - pat.dob)) / (((((60 * 60) * 24))::numeric * 365.242))::double precision))::numeric, 4) AS age,
    adm.ethnicity,
    adm.admission_type,
    adm.hospital_expire_flag,
    dense_rank() OVER (PARTITION BY adm.subject_id ORDER BY adm.admittime) AS hospstay_seq,
        CASE
            WHEN (dense_rank() OVER (PARTITION BY adm.subject_id ORDER BY adm.admittime) = 1) THEN 'Y'::text
            ELSE 'N'::text
        END AS first_hosp_stay,
    ie.intime,
    ie.outtime,
    round(((date_part('epoch'::text, (ie.outtime - ie.intime)) / (((60 * 60) * 24))::double precision))::numeric, 4) AS los_icu,
    dense_rank() OVER (PARTITION BY ie.hadm_id ORDER BY ie.intime) AS icustay_seq,
        CASE
            WHEN (dense_rank() OVER (PARTITION BY ie.hadm_id ORDER BY ie.intime) = 1) THEN 'Y'::text
            ELSE 'N'::text
        END AS first_icu_stay
   FROM ((mimiciii.icustays ie
     JOIN mimiciii.admissions adm ON ((ie.hadm_id = adm.hadm_id)))
     JOIN mimiciii.patients pat ON ((ie.subject_id = pat.subject_id)))
  WHERE (adm.has_chartevents_data = 1)
  ORDER BY ie.subject_id, adm.admittime, ie.intime;

