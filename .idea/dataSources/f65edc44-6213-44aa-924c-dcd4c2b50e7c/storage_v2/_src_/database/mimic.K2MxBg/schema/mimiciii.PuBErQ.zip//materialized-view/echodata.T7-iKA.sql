CREATE MATERIALIZED VIEW echodata AS SELECT ne.row_id,
    ne.subject_id,
    ne.hadm_id,
    ne.chartdate,
    (to_timestamp((to_char(ne.chartdate, 'DD-MM-YYYY'::text) || "substring"(ne.text, 'Date/Time: [\[\]0-9*-]+ at ([0-9:]+)'::text)), 'DD-MM-YYYYHH24:MI'::text))::timestamp without time zone AS charttime,
    "substring"(ne.text, 'Indication: (.*?)\n'::text) AS indication,
        CASE
            WHEN ("substring"(ne.text, 'Height: \(in\) (.*?)\n'::text) ~~ '%*%'::text) THEN NULL::numeric
            ELSE ("substring"(ne.text, 'Height: \(in\) (.*?)\n'::text))::numeric
        END AS height,
        CASE
            WHEN ("substring"(ne.text, 'Weight \(lb\): (.*?)\n'::text) ~~ '%*%'::text) THEN NULL::numeric
            ELSE ("substring"(ne.text, 'Weight \(lb\): (.*?)\n'::text))::numeric
        END AS weight,
        CASE
            WHEN ("substring"(ne.text, 'BSA \(m2\): (.*?) m2\n'::text) ~~ '%*%'::text) THEN NULL::numeric
            ELSE ("substring"(ne.text, 'BSA \(m2\): (.*?) m2\n'::text))::numeric
        END AS bsa,
    "substring"(ne.text, 'BP \(mm Hg\): (.*?)\n'::text) AS bp,
        CASE
            WHEN ("substring"(ne.text, 'BP \(mm Hg\): ([0-9]+)/[0-9]+?\n'::text) ~~ '%*%'::text) THEN NULL::numeric
            ELSE ("substring"(ne.text, 'BP \(mm Hg\): ([0-9]+)/[0-9]+?\n'::text))::numeric
        END AS bpsys,
        CASE
            WHEN ("substring"(ne.text, 'BP \(mm Hg\): [0-9]+/([0-9]+?)\n'::text) ~~ '%*%'::text) THEN NULL::numeric
            ELSE ("substring"(ne.text, 'BP \(mm Hg\): [0-9]+/([0-9]+?)\n'::text))::numeric
        END AS bpdias,
        CASE
            WHEN ("substring"(ne.text, 'HR \(bpm\): ([0-9]+?)\n'::text) ~~ '%*%'::text) THEN NULL::numeric
            ELSE ("substring"(ne.text, 'HR \(bpm\): ([0-9]+?)\n'::text))::numeric
        END AS hr,
    "substring"(ne.text, 'Status: (.*?)\n'::text) AS status,
    "substring"(ne.text, 'Test: (.*?)\n'::text) AS test,
    "substring"(ne.text, 'Doppler: (.*?)\n'::text) AS doppler,
    "substring"(ne.text, 'Contrast: (.*?)\n'::text) AS contrast,
    "substring"(ne.text, 'Technical Quality: (.*?)\n'::text) AS technicalquality
   FROM mimiciii.noteevents ne
  WHERE ((ne.category)::text = 'Echo'::text);

