CREATE MATERIALIZED VIEW oliguria_chartevents AS SELECT og.subject_id,
    og.hadm_id,
    og.icustay_id,
    ce.charttime,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[211, 220045])) AND (ce.valuenum > (0)::double precision) AND (ce.valuenum < (300)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS heartrate,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[51, 442, 455, 6701, 220179, 220050])) AND (ce.valuenum > (0)::double precision) AND (ce.valuenum < (400)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS sysbp,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[8368, 8440, 8441, 8555, 220180, 220051])) AND (ce.valuenum > (0)::double precision) AND (ce.valuenum < (300)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS diasbp,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[456, 52, 6702, 443, 220052, 220181, 225312])) AND (ce.valuenum > (0)::double precision) AND (ce.valuenum < (300)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS meanbp,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[615, 618, 220210, 224690])) AND (ce.valuenum > (0)::double precision) AND (ce.valuenum < (70)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS resprate,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[223761, 678])) AND (ce.valuenum > (70)::double precision) AND (ce.valuenum < (120)::double precision)) THEN ((ce.valuenum - (32)::double precision) / (1.8)::double precision)
            WHEN ((ce.itemid = ANY (ARRAY[223762, 676])) AND (ce.valuenum > (10)::double precision) AND (ce.valuenum < (50)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS tempc,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[646, 220277])) AND (ce.valuenum > (0)::double precision) AND (ce.valuenum <= (100)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS spo2,
    max(
        CASE
            WHEN ((ce.itemid = ANY (ARRAY[807, 811, 1529, 3745, 3744, 225664, 220621, 226537])) AND (ce.valuenum > (0)::double precision)) THEN ce.valuenum
            ELSE NULL::double precision
        END) AS glucose
   FROM (oliguria og
     LEFT JOIN mimiciii.chartevents ce ON (((og.subject_id = ce.subject_id) AND (og.hadm_id = ce.hadm_id) AND (og.icustay_id = ce.icustay_id) AND ((ce.charttime >= og.intime) AND (ce.charttime <= og.uo_charttime2)))))
  WHERE (ce.itemid = ANY (ARRAY[211, 220045, 51, 442, 455, 6701, 220179, 220050, 8368, 8440, 8441, 8555, 220180, 220051, 456, 52, 6702, 443, 220052, 220181, 225312, 618, 615, 220210, 224690, 646, 220277, 807, 811, 1529, 3745, 3744, 225664, 220621, 226537, 223762, 676, 223761, 678]))
  GROUP BY og.subject_id, og.hadm_id, og.icustay_id, ce.charttime;

