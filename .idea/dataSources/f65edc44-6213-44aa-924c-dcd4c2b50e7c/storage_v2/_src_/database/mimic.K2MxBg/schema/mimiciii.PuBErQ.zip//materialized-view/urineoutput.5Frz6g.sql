CREATE MATERIALIZED VIEW urineoutput AS SELECT oe.icustay_id,
    oe.charttime,
    sum(
        CASE
            WHEN (oe.itemid = 227488) THEN (('-1'::integer)::double precision * oe.value)
            ELSE oe.value
        END) AS value
   FROM mimiciii.outputevents oe
  WHERE ((oe.itemid = ANY (ARRAY[40055, 43175, 40069, 40094, 40715, 40473, 40085, 40057, 40056, 40405, 40428, 40086, 40096, 40651, 226559, 226560, 226561, 226584, 226563, 226564, 226565, 226567, 226557, 226558, 227488, 227489])) AND (oe.value < (5000)::double precision) AND (oe.icustay_id IS NOT NULL))
  GROUP BY oe.icustay_id, oe.charttime;

