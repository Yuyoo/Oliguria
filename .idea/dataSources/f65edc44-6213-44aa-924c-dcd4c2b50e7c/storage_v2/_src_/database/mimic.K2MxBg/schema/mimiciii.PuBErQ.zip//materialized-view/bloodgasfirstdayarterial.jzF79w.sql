CREATE MATERIALIZED VIEW bloodgasfirstdayarterial AS WITH stg_spo2 AS (
         SELECT chartevents.subject_id,
            chartevents.hadm_id,
            chartevents.icustay_id,
            chartevents.charttime,
            max(
                CASE
                    WHEN ((chartevents.valuenum <= (0)::double precision) OR (chartevents.valuenum > (100)::double precision)) THEN NULL::double precision
                    ELSE chartevents.valuenum
                END) AS spo2
           FROM mimiciii.chartevents
          WHERE (chartevents.itemid = ANY (ARRAY[646, 220277]))
          GROUP BY chartevents.subject_id, chartevents.hadm_id, chartevents.icustay_id, chartevents.charttime
        ), stg_fio2 AS (
         SELECT chartevents.subject_id,
            chartevents.hadm_id,
            chartevents.icustay_id,
            chartevents.charttime,
            max(
                CASE
                    WHEN (chartevents.itemid = 223835) THEN
                    CASE
                        WHEN ((chartevents.valuenum > (0)::double precision) AND (chartevents.valuenum <= (1)::double precision)) THEN (chartevents.valuenum * (100)::double precision)
                        WHEN ((chartevents.valuenum > (1)::double precision) AND (chartevents.valuenum < (21)::double precision)) THEN NULL::double precision
                        WHEN ((chartevents.valuenum >= (21)::double precision) AND (chartevents.valuenum <= (100)::double precision)) THEN chartevents.valuenum
                        ELSE NULL::double precision
                    END
                    WHEN (chartevents.itemid = ANY (ARRAY[3420, 3422])) THEN chartevents.valuenum
                    WHEN ((chartevents.itemid = 190) AND (chartevents.valuenum > (0.20)::double precision) AND (chartevents.valuenum < (1)::double precision)) THEN (chartevents.valuenum * (100)::double precision)
                    ELSE NULL::double precision
                END) AS fio2_chartevents
           FROM mimiciii.chartevents
          WHERE (chartevents.itemid = ANY (ARRAY[3420, 190, 223835, 3422]))
          GROUP BY chartevents.subject_id, chartevents.hadm_id, chartevents.icustay_id, chartevents.charttime
        ), stg2 AS (
         SELECT bg.subject_id,
            bg.hadm_id,
            bg.icustay_id,
            bg.charttime,
            bg.specimen,
            bg.aado2,
            bg.baseexcess,
            bg.bicarbonate,
            bg.totalco2,
            bg.carboxyhemoglobin,
            bg.chloride,
            bg.calcium,
            bg.glucose,
            bg.hematocrit,
            bg.hemoglobin,
            bg.intubated,
            bg.lactate,
            bg.methemoglobin,
            bg.o2flow,
            bg.fio2,
            bg.so2,
            bg.pco2,
            bg.peep,
            bg.ph,
            bg.po2,
            bg.potassium,
            bg.requiredo2,
            bg.sodium,
            bg.temperature,
            bg.tidalvolume,
            bg.ventilationrate,
            bg.ventilator,
            row_number() OVER (PARTITION BY bg.icustay_id, bg.charttime ORDER BY s1.charttime DESC) AS lastrowspo2,
            s1.spo2
           FROM (mimiciii.bloodgasfirstday bg
             LEFT JOIN stg_spo2 s1 ON (((bg.icustay_id = s1.icustay_id) AND ((s1.charttime >= (bg.charttime - '02:00:00'::interval hour)) AND (s1.charttime <= bg.charttime)))))
          WHERE (bg.po2 IS NOT NULL)
        ), stg3 AS (
         SELECT bg.subject_id,
            bg.hadm_id,
            bg.icustay_id,
            bg.charttime,
            bg.specimen,
            bg.aado2,
            bg.baseexcess,
            bg.bicarbonate,
            bg.totalco2,
            bg.carboxyhemoglobin,
            bg.chloride,
            bg.calcium,
            bg.glucose,
            bg.hematocrit,
            bg.hemoglobin,
            bg.intubated,
            bg.lactate,
            bg.methemoglobin,
            bg.o2flow,
            bg.fio2,
            bg.so2,
            bg.pco2,
            bg.peep,
            bg.ph,
            bg.po2,
            bg.potassium,
            bg.requiredo2,
            bg.sodium,
            bg.temperature,
            bg.tidalvolume,
            bg.ventilationrate,
            bg.ventilator,
            bg.lastrowspo2,
            bg.spo2,
            row_number() OVER (PARTITION BY bg.icustay_id, bg.charttime ORDER BY s2.charttime DESC) AS lastrowfio2,
            s2.fio2_chartevents,
            ((1)::double precision / ((1)::double precision + exp((- (((((((((((((('-0.02544'::numeric)::double precision + ((0.04598)::double precision * bg.po2)) + COALESCE((('-0.15356'::numeric)::double precision * bg.spo2), ((('-0.15356'::numeric * 97.49420) + 0.13429))::double precision)) + COALESCE(((0.00621)::double precision * s2.fio2_chartevents), (((0.00621 * 51.49550) + '-0.24958'::numeric))::double precision)) + COALESCE(((0.10559)::double precision * bg.hemoglobin), (((0.10559 * 10.32307) + 0.05954))::double precision)) + COALESCE(((0.13251)::double precision * bg.so2), (((0.13251 * 93.66539) + '-0.23172'::numeric))::double precision)) + COALESCE((('-0.01511'::numeric)::double precision * bg.pco2), ((('-0.01511'::numeric * 42.08866) + '-0.01630'::numeric))::double precision)) + COALESCE(((0.01480)::double precision * bg.fio2), (((0.01480 * 63.97836) + '-0.31142'::numeric))::double precision)) + COALESCE((('-0.00200'::numeric)::double precision * bg.aado2), ((('-0.00200'::numeric * 442.21186) + '-0.01328'::numeric))::double precision)) + COALESCE((('-0.03220'::numeric)::double precision * bg.bicarbonate), ((('-0.03220'::numeric * 22.96894) + '-0.06535'::numeric))::double precision)) + COALESCE(((0.05384)::double precision * bg.totalco2), (((0.05384 * 24.72632) + '-0.01405'::numeric))::double precision)) + COALESCE(((0.08202)::double precision * bg.lactate), (((0.08202 * 3.06436) + 0.06038))::double precision)) + COALESCE(((0.10956)::double precision * bg.ph), (((0.10956 * 7.36233) + '-0.00617'::numeric))::double precision)) + COALESCE(((0.00848)::double precision * bg.o2flow), (((0.00848 * 7.59362) + '-0.35803'::numeric))::double precision)))))) AS specimen_prob
           FROM (stg2 bg
             LEFT JOIN stg_fio2 s2 ON (((bg.icustay_id = s2.icustay_id) AND ((s2.charttime >= (bg.charttime - '04:00:00'::interval hour)) AND (s2.charttime <= bg.charttime)))))
          WHERE (bg.lastrowspo2 = 1)
        )
 SELECT stg3.subject_id,
    stg3.hadm_id,
    stg3.icustay_id,
    stg3.charttime,
    stg3.specimen,
        CASE
            WHEN (stg3.specimen IS NOT NULL) THEN stg3.specimen
            WHEN (stg3.specimen_prob > (0.75)::double precision) THEN 'ART'::text
            ELSE NULL::text
        END AS specimen_pred,
    stg3.specimen_prob,
    stg3.so2,
    stg3.spo2,
    stg3.po2,
    stg3.pco2,
    stg3.fio2_chartevents,
    stg3.fio2,
    stg3.aado2,
        CASE
            WHEN ((stg3.po2 IS NOT NULL) AND (stg3.pco2 IS NOT NULL) AND (COALESCE(stg3.fio2, stg3.fio2_chartevents) IS NOT NULL)) THEN ((((COALESCE(stg3.fio2, stg3.fio2_chartevents) / (100)::double precision) * ((760 - 47))::double precision) - (stg3.pco2 / (0.8)::double precision)) - stg3.po2)
            ELSE NULL::double precision
        END AS aado2_calc,
        CASE
            WHEN ((stg3.po2 IS NOT NULL) AND (COALESCE(stg3.fio2, stg3.fio2_chartevents) IS NOT NULL)) THEN (((100)::double precision * stg3.po2) / COALESCE(stg3.fio2, stg3.fio2_chartevents))
            ELSE NULL::double precision
        END AS pao2fio2,
    stg3.ph,
    stg3.baseexcess,
    stg3.bicarbonate,
    stg3.totalco2,
    stg3.hematocrit,
    stg3.hemoglobin,
    stg3.carboxyhemoglobin,
    stg3.methemoglobin,
    stg3.chloride,
    stg3.calcium,
    stg3.temperature,
    stg3.potassium,
    stg3.sodium,
    stg3.lactate,
    stg3.glucose,
    stg3.intubated,
    stg3.tidalvolume,
    stg3.ventilationrate,
    stg3.ventilator,
    stg3.peep,
    stg3.o2flow,
    stg3.requiredo2
   FROM stg3
  WHERE ((stg3.lastrowfio2 = 1) AND ((stg3.specimen = 'ART'::text) OR (stg3.specimen_prob > (0.75)::double precision)))
  ORDER BY stg3.icustay_id, stg3.charttime;
