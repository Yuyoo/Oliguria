CREATE MATERIALIZED VIEW output_day AS WITH tmp AS (
         SELECT o.subject_id,
            o.hadm_id,
            o.icustay_id,
            (o.charttime)::date AS chart_date,
            o.value
           FROM mimiciii.outputevents o
        )
 SELECT tmp.subject_id,
    tmp.hadm_id,
    tmp.icustay_id,
    tmp.chart_date,
    sum(tmp.value) AS sum
   FROM tmp
  GROUP BY tmp.subject_id, tmp.hadm_id, tmp.icustay_id, tmp.chart_date;
