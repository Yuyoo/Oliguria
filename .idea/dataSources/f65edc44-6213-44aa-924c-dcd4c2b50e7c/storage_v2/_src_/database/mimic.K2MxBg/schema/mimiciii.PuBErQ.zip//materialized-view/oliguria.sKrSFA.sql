CREATE MATERIALIZED VIEW oliguria AS WITH uo1 AS (
         SELECT DISTINCT icud.subject_id,
            icu.hadm_id,
            uo.icustay_id,
            min(uo.charttime) AS charttime
           FROM ((mimiciii.kdigo_uo uo
             JOIN mimiciii.icustays icu ON ((icu.icustay_id = uo.icustay_id)))
             JOIN mimiciii.icustay_detail icud ON ((icu.icustay_id = icud.icustay_id)))
          WHERE ((uo.urineoutput_24hr < (400)::double precision) AND (round(((date_part('epoch'::text, (uo.charttime - icu.intime)) / (((60 * 60) * 24))::double precision))::numeric, 4) > (2)::numeric) AND (round(((date_part('epoch'::text, (icu.outtime - uo.charttime)) / (((60 * 60) * 24))::double precision))::numeric, 4) > (1)::numeric) AND (icud.icustay_seq = 1) AND (icud.hospstay_seq = 1) AND (icud.age > (18)::numeric))
          GROUP BY icud.subject_id, icu.hadm_id, uo.icustay_id
        ), uo2 AS (
         SELECT uo1.subject_id,
            uo1.hadm_id,
            uo1.icustay_id,
            uo1.charttime,
            uo.weight,
            uo.urineoutput_24hr
           FROM (uo1
             JOIN mimiciii.kdigo_uo uo ON (((uo.icustay_id = uo1.icustay_id) AND (uo1.charttime = uo.charttime))))
        ), ex AS (
         SELECT ce.subject_id,
            ce.hadm_id,
            ce.icustay_id,
            ce.charttime,
            ce.itemid,
            ce.valuenum,
            uo2.charttime AS uo_charttime1,
            (uo2.charttime + '1 day'::interval) AS uo_charttime2,
            uo2.urineoutput_24hr
           FROM (uo2
             LEFT JOIN mimiciii.chartevents ce ON (((uo2.subject_id = ce.subject_id) AND (uo2.hadm_id = ce.hadm_id) AND (uo2.icustay_id = uo2.icustay_id))))
          WHERE (((ce.itemid = ANY (ARRAY[211, 220045])) OR (ce.itemid = ANY (ARRAY[6, 51, 455, 6701, 220050, 220179]))) AND (ce.charttime >= uo2.charttime) AND (ce.charttime <= (uo2.charttime + '1 day'::interval)) AND (ce.valuenum > (0)::double precision))
        ), ct AS (
         SELECT ex.subject_id,
            ex.hadm_id,
            ex.icustay_id,
            ex.uo_charttime1,
            ex.uo_charttime2,
            ex.urineoutput_24hr,
            le.itemid AS creatinine,
            le.charttime,
            le.valuenum,
            le.flag,
            icud.intime,
            icud.outtime,
            icud.los_icu
           FROM ((ex
             LEFT JOIN mimiciii.labevents le ON (((ex.subject_id = le.subject_id) AND (ex.hadm_id = le.hadm_id))))
             LEFT JOIN mimiciii.icustay_detail icud ON (((ex.subject_id = icud.subject_id) AND (ex.hadm_id = icud.hadm_id) AND (ex.icustay_id = icud.icustay_id))))
          WHERE ((le.itemid = 50912) AND (le.charttime <= icud.outtime))
        ), ct_first AS (
         SELECT ct.subject_id,
            ct.hadm_id,
            ct.icustay_id,
            min(ct.charttime) AS first_charttime
           FROM ct
          GROUP BY ct.subject_id, ct.hadm_id, ct.icustay_id
        ), ct2 AS (
         SELECT ct.subject_id,
            ct.hadm_id,
            ct.icustay_id,
            ct.uo_charttime1,
            ct.uo_charttime2,
            ct.urineoutput_24hr,
            ct.creatinine,
            ct.charttime,
            ct.valuenum,
            ct.flag,
            ct.intime,
            ct.outtime,
            ct.los_icu
           FROM (ct_first
             JOIN ct ON ((ct_first.first_charttime = ct.charttime)))
          WHERE (ct.valuenum < (4)::double precision)
        ), ct_in AS (
         SELECT ct.subject_id,
            ct.hadm_id,
            ct.icustay_id,
            count(ct.charttime) AS count
           FROM ct
          WHERE ((ct.charttime >= ct.intime) AND (ct.charttime <= ct.outtime))
          GROUP BY ct.subject_id, ct.hadm_id, ct.icustay_id
         HAVING (count(ct.charttime) >= 2)
        )
 SELECT DISTINCT ct2.subject_id,
    ct2.hadm_id,
    ct2.icustay_id,
    ct2.uo_charttime1,
    ct2.uo_charttime2,
    ct2.urineoutput_24hr,
    ct2.intime,
    ct2.outtime
   FROM (ct2
     JOIN ct_in ON (((ct2.subject_id = ct_in.subject_id) AND (ct2.hadm_id = ct_in.hadm_id) AND (ct2.icustay_id = ct_in.icustay_id))));

