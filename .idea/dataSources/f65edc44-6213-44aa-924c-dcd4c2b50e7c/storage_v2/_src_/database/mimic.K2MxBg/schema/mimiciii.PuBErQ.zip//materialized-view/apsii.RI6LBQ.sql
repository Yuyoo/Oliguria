CREATE MATERIALIZED VIEW apsii AS WITH bg AS (
         SELECT bg.icustay_id,
            bg.charttime,
            bg.po2 AS pao2,
            bg.aado2,
                CASE
                    WHEN ((COALESCE(bg.fio2, bg.fio2_chartevents) IS NOT NULL) AND (vd.icustay_id IS NOT NULL) AND (COALESCE(bg.fio2, bg.fio2_chartevents) >= (50)::double precision)) THEN row_number() OVER (PARTITION BY bg.icustay_id ORDER BY bg.aado2 DESC)
                    ELSE NULL::bigint
                END AS aado2_rn,
                CASE
                    WHEN (COALESCE(bg.fio2, bg.fio2_chartevents) >= (50)::double precision) THEN NULL::bigint
                    WHEN (vd.icustay_id IS NOT NULL) THEN NULL::bigint
                    ELSE row_number() OVER (PARTITION BY bg.icustay_id ORDER BY bg.po2 DESC)
                END AS pao2_rn
           FROM (mimiciii.bloodgasfirstdayarterial bg
             LEFT JOIN mimiciii.ventdurations vd ON (((bg.icustay_id = vd.icustay_id) AND (bg.charttime >= vd.starttime) AND (bg.charttime <= vd.endtime))))
        ), acidbase AS (
         SELECT bg.icustay_id,
            bg.ph,
                CASE
                    WHEN (bg.ph IS NULL) THEN NULL::integer
                    WHEN (bg.ph < (7.15)::double precision) THEN 4
                    WHEN (bg.ph < (7.25)::double precision) THEN 3
                    WHEN (bg.ph < (7.33)::double precision) THEN 2
                    WHEN (bg.ph < (7.50)::double precision) THEN 0
                    WHEN (bg.ph < (7.60)::double precision) THEN 1
                    WHEN (bg.ph < (7.70)::double precision) THEN 3
                    ELSE 4
                END AS acidbase_score
           FROM mimiciii.bloodgasfirstdayarterial bg
          WHERE (bg.ph IS NOT NULL)
        ), acidbase_max AS (
         SELECT acidbase.icustay_id,
            acidbase.acidbase_score,
            acidbase.ph,
                CASE
                    WHEN (acidbase.ph IS NOT NULL) THEN row_number() OVER (PARTITION BY acidbase.icustay_id ORDER BY acidbase.acidbase_score DESC)
                    ELSE NULL::bigint
                END AS acidbase_rn
           FROM acidbase
        ), arf AS (
         SELECT ie_1.icustay_id,
                CASE
                    WHEN ((labs.creatinine_max >= (1.5)::double precision) AND (uo.urineoutput < (410)::double precision) AND (icd.ckd = 0)) THEN 1
                    ELSE 0
                END AS arf
           FROM (((mimiciii.icustays ie_1
             LEFT JOIN mimiciii.uofirstday uo ON ((ie_1.icustay_id = uo.icustay_id)))
             LEFT JOIN mimiciii.labsfirstday labs ON ((ie_1.icustay_id = labs.icustay_id)))
             LEFT JOIN ( SELECT diagnoses_icd.hadm_id,
                    max(
                        CASE
                            WHEN ((diagnoses_icd.icd9_code)::text = ANY ((ARRAY['5854'::character varying, '5855'::character varying, '5856'::character varying])::text[])) THEN 1
                            ELSE 0
                        END) AS ckd
                   FROM mimiciii.diagnoses_icd
                  GROUP BY diagnoses_icd.hadm_id) icd ON ((ie_1.hadm_id = icd.hadm_id)))
        ), cohort AS (
         SELECT ie_1.subject_id,
            ie_1.hadm_id,
            ie_1.icustay_id,
            ie_1.intime,
            ie_1.outtime,
            vital.heartrate_min,
            vital.heartrate_max,
            vital.meanbp_min,
            vital.meanbp_max,
            vital.tempc_min,
            vital.tempc_max,
            vital.resprate_min,
            vital.resprate_max,
            pa.pao2,
            aa.aado2,
            ab.ph,
            ab.acidbase_score,
            labs.hematocrit_min,
            labs.hematocrit_max,
            labs.wbc_min,
            labs.wbc_max,
            labs.creatinine_min,
            labs.creatinine_max,
            labs.sodium_min,
            labs.sodium_max,
            labs.potassium_min,
            labs.potassium_max,
                CASE
                    WHEN ((labs.glucose_max IS NULL) AND (vital.glucose_max IS NULL)) THEN NULL::double precision
                    WHEN ((labs.glucose_max IS NULL) OR (vital.glucose_max > labs.glucose_max)) THEN vital.glucose_max
                    WHEN ((vital.glucose_max IS NULL) OR (labs.glucose_max > vital.glucose_max)) THEN labs.glucose_max
                    ELSE labs.glucose_max
                END AS glucose_max,
                CASE
                    WHEN ((labs.glucose_min IS NULL) AND (vital.glucose_min IS NULL)) THEN NULL::double precision
                    WHEN ((labs.glucose_min IS NULL) OR (vital.glucose_min < labs.glucose_min)) THEN vital.glucose_min
                    WHEN ((vital.glucose_min IS NULL) OR (labs.glucose_min < vital.glucose_min)) THEN labs.glucose_min
                    ELSE labs.glucose_min
                END AS glucose_min,
            vent.mechvent AS vent,
            uo.urineoutput,
            gcs.mingcs,
            gcs.gcsmotor,
            gcs.gcsverbal,
            gcs.gcseyes,
            gcs.endotrachflag,
            arf.arf
           FROM (((((((((((mimiciii.icustays ie_1
             JOIN mimiciii.admissions adm ON ((ie_1.hadm_id = adm.hadm_id)))
             JOIN mimiciii.patients pat ON ((ie_1.subject_id = pat.subject_id)))
             LEFT JOIN bg pa ON (((ie_1.icustay_id = pa.icustay_id) AND (pa.pao2_rn = 1))))
             LEFT JOIN bg aa ON (((ie_1.icustay_id = aa.icustay_id) AND (aa.aado2_rn = 1))))
             LEFT JOIN acidbase_max ab ON (((ie_1.icustay_id = ab.icustay_id) AND (ab.acidbase_rn = 1))))
             LEFT JOIN arf ON ((ie_1.icustay_id = arf.icustay_id)))
             LEFT JOIN mimiciii.ventfirstday vent ON ((ie_1.icustay_id = vent.icustay_id)))
             LEFT JOIN mimiciii.gcsfirstday gcs ON ((ie_1.icustay_id = gcs.icustay_id)))
             LEFT JOIN mimiciii.vitalsfirstday vital ON ((ie_1.icustay_id = vital.icustay_id)))
             LEFT JOIN mimiciii.uofirstday uo ON ((ie_1.icustay_id = uo.icustay_id)))
             LEFT JOIN mimiciii.labsfirstday labs ON ((ie_1.icustay_id = labs.icustay_id)))
        ), score_min AS (
         SELECT cohort.subject_id,
            cohort.hadm_id,
            cohort.icustay_id,
                CASE
                    WHEN (cohort.heartrate_min IS NULL) THEN NULL::integer
                    WHEN (cohort.heartrate_min < (40)::double precision) THEN 4
                    WHEN (cohort.heartrate_min < (55)::double precision) THEN 3
                    WHEN (cohort.heartrate_min < (70)::double precision) THEN 2
                    WHEN (cohort.heartrate_min < (110)::double precision) THEN 0
                    WHEN (cohort.heartrate_min < (140)::double precision) THEN 2
                    WHEN (cohort.heartrate_min < (180)::double precision) THEN 3
                    WHEN (cohort.heartrate_min >= (180)::double precision) THEN 4
                    ELSE NULL::integer
                END AS hr_score,
                CASE
                    WHEN (cohort.meanbp_min IS NULL) THEN NULL::integer
                    WHEN (cohort.meanbp_min < (50)::double precision) THEN 4
                    WHEN (cohort.meanbp_min < (70)::double precision) THEN 2
                    WHEN (cohort.meanbp_min < (110)::double precision) THEN 0
                    WHEN (cohort.meanbp_min < (130)::double precision) THEN 2
                    WHEN (cohort.meanbp_min < (160)::double precision) THEN 3
                    WHEN (cohort.meanbp_min >= (160)::double precision) THEN 4
                    ELSE NULL::integer
                END AS meanbp_score,
                CASE
                    WHEN (cohort.tempc_min IS NULL) THEN NULL::integer
                    WHEN (cohort.tempc_min < (30.0)::double precision) THEN 4
                    WHEN (cohort.tempc_min < (32.0)::double precision) THEN 3
                    WHEN (cohort.tempc_min < (34.0)::double precision) THEN 2
                    WHEN (cohort.tempc_min < (36.0)::double precision) THEN 1
                    WHEN (cohort.tempc_min < (38.5)::double precision) THEN 0
                    WHEN (cohort.tempc_min < (39.0)::double precision) THEN 1
                    WHEN (cohort.tempc_min < (41.0)::double precision) THEN 3
                    WHEN (cohort.tempc_min >= (41.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS temp_score,
                CASE
                    WHEN (cohort.resprate_min IS NULL) THEN NULL::integer
                    WHEN ((cohort.vent = 1) AND (cohort.resprate_min < (14)::double precision)) THEN 0
                    WHEN (cohort.resprate_min < (6)::double precision) THEN 4
                    WHEN (cohort.resprate_min < (10)::double precision) THEN 2
                    WHEN (cohort.resprate_min < (12)::double precision) THEN 1
                    WHEN (cohort.resprate_min < (25)::double precision) THEN 0
                    WHEN (cohort.resprate_min < (35)::double precision) THEN 1
                    WHEN (cohort.resprate_min < (50)::double precision) THEN 3
                    WHEN (cohort.resprate_min >= (50)::double precision) THEN 4
                    ELSE NULL::integer
                END AS resprate_score,
                CASE
                    WHEN (cohort.hematocrit_min IS NULL) THEN NULL::integer
                    WHEN (cohort.hematocrit_min < (20.0)::double precision) THEN 4
                    WHEN (cohort.hematocrit_min < (30.0)::double precision) THEN 3
                    WHEN (cohort.hematocrit_min < (46.0)::double precision) THEN 0
                    WHEN (cohort.hematocrit_min < (50.0)::double precision) THEN 1
                    WHEN (cohort.hematocrit_min < (60.0)::double precision) THEN 2
                    WHEN (cohort.hematocrit_min >= (60.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS hematocrit_score,
                CASE
                    WHEN (cohort.wbc_min IS NULL) THEN NULL::integer
                    WHEN (cohort.wbc_min < (1.0)::double precision) THEN 4
                    WHEN (cohort.wbc_min < (3.0)::double precision) THEN 2
                    WHEN (cohort.wbc_min < (15.0)::double precision) THEN 0
                    WHEN (cohort.wbc_min < (20.0)::double precision) THEN 1
                    WHEN (cohort.wbc_min < (40.0)::double precision) THEN 2
                    WHEN (cohort.wbc_min >= (40.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS wbc_score,
                CASE
                    WHEN (cohort.creatinine_min IS NULL) THEN NULL::integer
                    WHEN (cohort.arf = 1) THEN
                    CASE
                        WHEN (cohort.creatinine_min < (0.6)::double precision) THEN 4
                        WHEN (cohort.creatinine_min < (1.5)::double precision) THEN 0
                        WHEN (cohort.creatinine_min < (2.0)::double precision) THEN 4
                        WHEN (cohort.creatinine_min < (3.5)::double precision) THEN 6
                        WHEN (cohort.creatinine_min >= (3.5)::double precision) THEN 8
                        ELSE NULL::integer
                    END
                    ELSE
                    CASE
                        WHEN (cohort.creatinine_min < (0.6)::double precision) THEN 2
                        WHEN (cohort.creatinine_min < (1.5)::double precision) THEN 0
                        WHEN (cohort.creatinine_min < (2.0)::double precision) THEN 2
                        WHEN (cohort.creatinine_min < (3.5)::double precision) THEN 3
                        WHEN (cohort.creatinine_min >= (3.5)::double precision) THEN 4
                        ELSE NULL::integer
                    END
                END AS creatinine_score,
                CASE
                    WHEN (cohort.sodium_min IS NULL) THEN NULL::integer
                    WHEN (cohort.sodium_min < (110)::double precision) THEN 4
                    WHEN (cohort.sodium_min < (120)::double precision) THEN 3
                    WHEN (cohort.sodium_min < (130)::double precision) THEN 2
                    WHEN (cohort.sodium_min < (150)::double precision) THEN 0
                    WHEN (cohort.sodium_min < (155)::double precision) THEN 1
                    WHEN (cohort.sodium_min < (160)::double precision) THEN 2
                    WHEN (cohort.sodium_min < (180)::double precision) THEN 3
                    WHEN (cohort.sodium_min >= (180)::double precision) THEN 4
                    ELSE NULL::integer
                END AS sodium_score,
                CASE
                    WHEN (cohort.potassium_min IS NULL) THEN NULL::integer
                    WHEN (cohort.potassium_min < (2.5)::double precision) THEN 4
                    WHEN (cohort.potassium_min < (3.0)::double precision) THEN 2
                    WHEN (cohort.potassium_min < (3.5)::double precision) THEN 1
                    WHEN (cohort.potassium_min < (5.5)::double precision) THEN 0
                    WHEN (cohort.potassium_min < (6.0)::double precision) THEN 1
                    WHEN (cohort.potassium_min < (7.0)::double precision) THEN 3
                    WHEN (cohort.potassium_min >= (7.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS potassium_score
           FROM cohort
        ), score_max AS (
         SELECT cohort.subject_id,
            cohort.hadm_id,
            cohort.icustay_id,
                CASE
                    WHEN (cohort.heartrate_max IS NULL) THEN NULL::integer
                    WHEN (cohort.heartrate_max < (40)::double precision) THEN 4
                    WHEN (cohort.heartrate_max < (55)::double precision) THEN 3
                    WHEN (cohort.heartrate_max < (70)::double precision) THEN 2
                    WHEN (cohort.heartrate_max < (110)::double precision) THEN 0
                    WHEN (cohort.heartrate_max < (140)::double precision) THEN 2
                    WHEN (cohort.heartrate_max < (180)::double precision) THEN 3
                    WHEN (cohort.heartrate_max >= (180)::double precision) THEN 4
                    ELSE NULL::integer
                END AS hr_score,
                CASE
                    WHEN (cohort.meanbp_max IS NULL) THEN NULL::integer
                    WHEN (cohort.meanbp_max < (50)::double precision) THEN 4
                    WHEN (cohort.meanbp_max < (70)::double precision) THEN 2
                    WHEN (cohort.meanbp_max < (110)::double precision) THEN 0
                    WHEN (cohort.meanbp_max < (130)::double precision) THEN 2
                    WHEN (cohort.meanbp_max < (160)::double precision) THEN 3
                    WHEN (cohort.meanbp_max >= (160)::double precision) THEN 4
                    ELSE NULL::integer
                END AS meanbp_score,
                CASE
                    WHEN (cohort.tempc_max IS NULL) THEN NULL::integer
                    WHEN (cohort.tempc_max < (30.0)::double precision) THEN 4
                    WHEN (cohort.tempc_max < (32.0)::double precision) THEN 3
                    WHEN (cohort.tempc_max < (34.0)::double precision) THEN 2
                    WHEN (cohort.tempc_max < (36.0)::double precision) THEN 1
                    WHEN (cohort.tempc_max < (38.5)::double precision) THEN 0
                    WHEN (cohort.tempc_max < (39.0)::double precision) THEN 1
                    WHEN (cohort.tempc_max < (41.0)::double precision) THEN 3
                    WHEN (cohort.tempc_max >= (41.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS temp_score,
                CASE
                    WHEN (cohort.resprate_max IS NULL) THEN NULL::integer
                    WHEN ((cohort.vent = 1) AND (cohort.resprate_max < (14)::double precision)) THEN 0
                    WHEN (cohort.resprate_max < (6)::double precision) THEN 4
                    WHEN (cohort.resprate_max < (10)::double precision) THEN 2
                    WHEN (cohort.resprate_max < (12)::double precision) THEN 1
                    WHEN (cohort.resprate_max < (25)::double precision) THEN 0
                    WHEN (cohort.resprate_max < (35)::double precision) THEN 1
                    WHEN (cohort.resprate_max < (50)::double precision) THEN 3
                    WHEN (cohort.resprate_max >= (50)::double precision) THEN 4
                    ELSE NULL::integer
                END AS resprate_score,
                CASE
                    WHEN (cohort.hematocrit_max IS NULL) THEN NULL::integer
                    WHEN (cohort.hematocrit_max < (20.0)::double precision) THEN 4
                    WHEN (cohort.hematocrit_max < (30.0)::double precision) THEN 3
                    WHEN (cohort.hematocrit_max < (46.0)::double precision) THEN 0
                    WHEN (cohort.hematocrit_max < (50.0)::double precision) THEN 1
                    WHEN (cohort.hematocrit_max < (60.0)::double precision) THEN 2
                    WHEN (cohort.hematocrit_max >= (60.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS hematocrit_score,
                CASE
                    WHEN (cohort.wbc_max IS NULL) THEN NULL::integer
                    WHEN (cohort.wbc_max < (1.0)::double precision) THEN 4
                    WHEN (cohort.wbc_max < (3.0)::double precision) THEN 2
                    WHEN (cohort.wbc_max < (15.0)::double precision) THEN 0
                    WHEN (cohort.wbc_max < (20.0)::double precision) THEN 1
                    WHEN (cohort.wbc_max < (40.0)::double precision) THEN 2
                    WHEN (cohort.wbc_max >= (40.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS wbc_score,
                CASE
                    WHEN (cohort.creatinine_max IS NULL) THEN NULL::integer
                    WHEN (cohort.arf = 1) THEN
                    CASE
                        WHEN (cohort.creatinine_max < (0.6)::double precision) THEN 4
                        WHEN (cohort.creatinine_max < (1.5)::double precision) THEN 0
                        WHEN (cohort.creatinine_max < (2.0)::double precision) THEN 4
                        WHEN (cohort.creatinine_max < (3.5)::double precision) THEN 6
                        WHEN (cohort.creatinine_max >= (3.5)::double precision) THEN 8
                        ELSE NULL::integer
                    END
                    ELSE
                    CASE
                        WHEN (cohort.creatinine_max < (0.6)::double precision) THEN 2
                        WHEN (cohort.creatinine_max < (1.5)::double precision) THEN 0
                        WHEN (cohort.creatinine_max < (2.0)::double precision) THEN 2
                        WHEN (cohort.creatinine_max < (3.5)::double precision) THEN 3
                        WHEN (cohort.creatinine_max >= (3.5)::double precision) THEN 4
                        ELSE NULL::integer
                    END
                END AS creatinine_score,
                CASE
                    WHEN (cohort.sodium_max IS NULL) THEN NULL::integer
                    WHEN (cohort.sodium_max < (110)::double precision) THEN 4
                    WHEN (cohort.sodium_max < (120)::double precision) THEN 3
                    WHEN (cohort.sodium_max < (130)::double precision) THEN 2
                    WHEN (cohort.sodium_max < (150)::double precision) THEN 0
                    WHEN (cohort.sodium_max < (155)::double precision) THEN 1
                    WHEN (cohort.sodium_max < (160)::double precision) THEN 2
                    WHEN (cohort.sodium_max < (180)::double precision) THEN 3
                    WHEN (cohort.sodium_max >= (180)::double precision) THEN 4
                    ELSE NULL::integer
                END AS sodium_score,
                CASE
                    WHEN (cohort.potassium_max IS NULL) THEN NULL::integer
                    WHEN (cohort.potassium_max < (2.5)::double precision) THEN 4
                    WHEN (cohort.potassium_max < (3.0)::double precision) THEN 2
                    WHEN (cohort.potassium_max < (3.5)::double precision) THEN 1
                    WHEN (cohort.potassium_max < (5.5)::double precision) THEN 0
                    WHEN (cohort.potassium_max < (6.0)::double precision) THEN 1
                    WHEN (cohort.potassium_max < (7.0)::double precision) THEN 3
                    WHEN (cohort.potassium_max >= (7.0)::double precision) THEN 4
                    ELSE NULL::integer
                END AS potassium_score
           FROM cohort
        ), scorecomp AS (
         SELECT co.subject_id,
            co.hadm_id,
            co.icustay_id,
            co.intime,
            co.outtime,
            co.heartrate_min,
            co.heartrate_max,
            co.meanbp_min,
            co.meanbp_max,
            co.tempc_min,
            co.tempc_max,
            co.resprate_min,
            co.resprate_max,
            co.pao2,
            co.aado2,
            co.ph,
            co.acidbase_score,
            co.hematocrit_min,
            co.hematocrit_max,
            co.wbc_min,
            co.wbc_max,
            co.creatinine_min,
            co.creatinine_max,
            co.sodium_min,
            co.sodium_max,
            co.potassium_min,
            co.potassium_max,
            co.glucose_max,
            co.glucose_min,
            co.vent,
            co.urineoutput,
            co.mingcs,
            co.gcsmotor,
            co.gcsverbal,
            co.gcseyes,
            co.endotrachflag,
            co.arf,
                CASE
                    WHEN (co.heartrate_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.heartrate_max - (75)::double precision)) > abs((co.heartrate_min - (75)::double precision))) THEN smax.hr_score
                    WHEN (abs((co.heartrate_max - (75)::double precision)) < abs((co.heartrate_min - (75)::double precision))) THEN smin.hr_score
                    WHEN ((abs((co.heartrate_max - (75)::double precision)) = abs((co.heartrate_min - (75)::double precision))) AND (smax.hr_score >= smin.hr_score)) THEN smax.hr_score
                    WHEN ((abs((co.heartrate_max - (75)::double precision)) = abs((co.heartrate_min - (75)::double precision))) AND (smax.hr_score < smin.hr_score)) THEN smin.hr_score
                    ELSE NULL::integer
                END AS hr_score,
                CASE
                    WHEN (co.meanbp_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.meanbp_max - (90)::double precision)) > abs((co.meanbp_min - (90)::double precision))) THEN smax.meanbp_score
                    WHEN (abs((co.meanbp_max - (90)::double precision)) < abs((co.meanbp_min - (90)::double precision))) THEN smin.meanbp_score
                    WHEN ((abs((co.meanbp_max - (90)::double precision)) = abs((co.meanbp_min - (90)::double precision))) AND (smax.meanbp_score >= smin.meanbp_score)) THEN smax.meanbp_score
                    WHEN ((abs((co.meanbp_max - (90)::double precision)) = abs((co.meanbp_min - (90)::double precision))) AND (smax.meanbp_score < smin.meanbp_score)) THEN smin.meanbp_score
                    ELSE NULL::integer
                END AS meanbp_score,
                CASE
                    WHEN (co.tempc_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.tempc_max - (38)::double precision)) > abs((co.tempc_min - (38)::double precision))) THEN smax.temp_score
                    WHEN (abs((co.tempc_max - (38)::double precision)) < abs((co.tempc_min - (38)::double precision))) THEN smin.temp_score
                    WHEN ((abs((co.tempc_max - (38)::double precision)) = abs((co.tempc_min - (38)::double precision))) AND (smax.temp_score >= smin.temp_score)) THEN smax.temp_score
                    WHEN ((abs((co.tempc_max - (38)::double precision)) = abs((co.tempc_min - (38)::double precision))) AND (smax.temp_score < smin.temp_score)) THEN smin.temp_score
                    ELSE NULL::integer
                END AS temp_score,
                CASE
                    WHEN (co.resprate_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.resprate_max - (19)::double precision)) > abs((co.resprate_min - (19)::double precision))) THEN smax.resprate_score
                    WHEN (abs((co.resprate_max - (19)::double precision)) < abs((co.resprate_min - (19)::double precision))) THEN smin.resprate_score
                    WHEN ((abs((co.resprate_max - (19)::double precision)) = abs((co.resprate_max - (19)::double precision))) AND (smax.resprate_score >= smin.resprate_score)) THEN smax.resprate_score
                    WHEN ((abs((co.resprate_max - (19)::double precision)) = abs((co.resprate_max - (19)::double precision))) AND (smax.resprate_score < smin.resprate_score)) THEN smin.resprate_score
                    ELSE NULL::integer
                END AS resprate_score,
                CASE
                    WHEN (co.hematocrit_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.hematocrit_max - (45.5)::double precision)) > abs((co.hematocrit_min - (45.5)::double precision))) THEN smax.hematocrit_score
                    WHEN (abs((co.hematocrit_max - (45.5)::double precision)) < abs((co.hematocrit_min - (45.5)::double precision))) THEN smin.hematocrit_score
                    WHEN ((abs((co.hematocrit_max - (45.5)::double precision)) = abs((co.hematocrit_max - (45.5)::double precision))) AND (smax.hematocrit_score >= smin.hematocrit_score)) THEN smax.hematocrit_score
                    WHEN ((abs((co.hematocrit_max - (45.5)::double precision)) = abs((co.hematocrit_max - (45.5)::double precision))) AND (smax.hematocrit_score < smin.hematocrit_score)) THEN smin.hematocrit_score
                    ELSE NULL::integer
                END AS hematocrit_score,
                CASE
                    WHEN (co.wbc_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.wbc_max - (11.5)::double precision)) > abs((co.wbc_min - (11.5)::double precision))) THEN smax.wbc_score
                    WHEN (abs((co.wbc_max - (11.5)::double precision)) < abs((co.wbc_min - (11.5)::double precision))) THEN smin.wbc_score
                    WHEN ((abs((co.wbc_max - (11.5)::double precision)) = abs((co.wbc_max - (11.5)::double precision))) AND (smax.wbc_score >= smin.wbc_score)) THEN smax.wbc_score
                    WHEN ((abs((co.wbc_max - (11.5)::double precision)) = abs((co.wbc_max - (11.5)::double precision))) AND (smax.wbc_score < smin.wbc_score)) THEN smin.wbc_score
                    ELSE NULL::integer
                END AS wbc_score,
                CASE
                    WHEN (co.creatinine_max IS NULL) THEN NULL::integer
                    WHEN (co.arf = 1) THEN smax.creatinine_score
                    WHEN (abs((co.creatinine_max - (1)::double precision)) > abs((co.creatinine_min - (1)::double precision))) THEN smax.creatinine_score
                    WHEN (abs((co.creatinine_max - (1)::double precision)) < abs((co.creatinine_min - (1)::double precision))) THEN smin.creatinine_score
                    WHEN (smax.creatinine_score >= smin.creatinine_score) THEN smax.creatinine_score
                    WHEN (smax.creatinine_score < smin.creatinine_score) THEN smin.creatinine_score
                    ELSE NULL::integer
                END AS creatinine_score,
                CASE
                    WHEN (co.sodium_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.sodium_max - (145.5)::double precision)) > abs((co.sodium_min - (145.5)::double precision))) THEN smax.sodium_score
                    WHEN (abs((co.sodium_max - (145.5)::double precision)) < abs((co.sodium_min - (145.5)::double precision))) THEN smin.sodium_score
                    WHEN ((abs((co.sodium_max - (145.5)::double precision)) = abs((co.sodium_max - (145.5)::double precision))) AND (smax.sodium_score >= smin.sodium_score)) THEN smax.sodium_score
                    WHEN ((abs((co.sodium_max - (145.5)::double precision)) = abs((co.sodium_max - (145.5)::double precision))) AND (smax.sodium_score < smin.sodium_score)) THEN smin.sodium_score
                    ELSE NULL::integer
                END AS sodium_score,
                CASE
                    WHEN (co.potassium_max IS NULL) THEN NULL::integer
                    WHEN (abs((co.potassium_max - (4.5)::double precision)) > abs((co.potassium_min - (4.5)::double precision))) THEN smax.potassium_score
                    WHEN (abs((co.potassium_max - (4.5)::double precision)) < abs((co.potassium_min - (4.5)::double precision))) THEN smin.potassium_score
                    WHEN ((abs((co.potassium_max - (4.5)::double precision)) = abs((co.potassium_max - (4.5)::double precision))) AND (smax.potassium_score >= smin.potassium_score)) THEN smax.potassium_score
                    WHEN ((abs((co.potassium_max - (4.5)::double precision)) = abs((co.potassium_max - (4.5)::double precision))) AND (smax.potassium_score < smin.potassium_score)) THEN smin.potassium_score
                    ELSE NULL::integer
                END AS potassium_score,
                CASE
                    WHEN (co.mingcs IS NULL) THEN NULL::double precision
                    WHEN (co.mingcs IS NOT NULL) THEN ((15)::double precision - co.mingcs)
                    ELSE NULL::double precision
                END AS gcs_score,
                CASE
                    WHEN ((co.pao2 IS NULL) AND (co.aado2 IS NULL)) THEN NULL::integer
                    WHEN (co.pao2 IS NOT NULL) THEN
                    CASE
                        WHEN (co.pao2 < (55)::double precision) THEN 4
                        WHEN (co.pao2 <= (60)::double precision) THEN 3
                        WHEN (co.pao2 <= (70)::double precision) THEN 1
                        ELSE 0
                    END
                    WHEN (co.aado2 IS NOT NULL) THEN
                    CASE
                        WHEN (co.aado2 < (200)::double precision) THEN 0
                        WHEN (co.aado2 < (350)::double precision) THEN 2
                        WHEN (co.aado2 < (500)::double precision) THEN 3
                        WHEN (co.aado2 >= (500)::double precision) THEN 4
                        ELSE 0
                    END
                    ELSE NULL::integer
                END AS pao2_aado2_score
           FROM ((cohort co
             LEFT JOIN score_min smin ON ((co.icustay_id = smin.icustay_id)))
             LEFT JOIN score_max smax ON ((co.icustay_id = smax.icustay_id)))
        ), score AS (
         SELECT s_1.subject_id,
            s_1.hadm_id,
            s_1.icustay_id,
            s_1.intime,
            s_1.outtime,
            s_1.heartrate_min,
            s_1.heartrate_max,
            s_1.meanbp_min,
            s_1.meanbp_max,
            s_1.tempc_min,
            s_1.tempc_max,
            s_1.resprate_min,
            s_1.resprate_max,
            s_1.pao2,
            s_1.aado2,
            s_1.ph,
            s_1.acidbase_score,
            s_1.hematocrit_min,
            s_1.hematocrit_max,
            s_1.wbc_min,
            s_1.wbc_max,
            s_1.creatinine_min,
            s_1.creatinine_max,
            s_1.sodium_min,
            s_1.sodium_max,
            s_1.potassium_min,
            s_1.potassium_max,
            s_1.glucose_max,
            s_1.glucose_min,
            s_1.vent,
            s_1.urineoutput,
            s_1.mingcs,
            s_1.gcsmotor,
            s_1.gcsverbal,
            s_1.gcseyes,
            s_1.endotrachflag,
            s_1.arf,
            s_1.hr_score,
            s_1.meanbp_score,
            s_1.temp_score,
            s_1.resprate_score,
            s_1.hematocrit_score,
            s_1.wbc_score,
            s_1.creatinine_score,
            s_1.sodium_score,
            s_1.potassium_score,
            s_1.gcs_score,
            s_1.pao2_aado2_score,
            ((((((((((((COALESCE(s_1.hr_score, 0) + COALESCE(s_1.meanbp_score, 0)) + COALESCE(s_1.temp_score, 0)) + COALESCE(s_1.resprate_score, 0)) + COALESCE(s_1.pao2_aado2_score, 0)) + COALESCE(s_1.hematocrit_score, 0)) + COALESCE(s_1.wbc_score, 0)) + COALESCE(s_1.creatinine_score, 0)) + COALESCE(s_1.sodium_score, 0)) + COALESCE(s_1.potassium_score, 0)) + COALESCE(s_1.acidbase_score, 0)))::double precision + COALESCE(s_1.gcs_score, (0)::double precision)) AS apsii
           FROM scorecomp s_1
        )
 SELECT ie.subject_id,
    ie.hadm_id,
    ie.icustay_id,
    s.apsii,
    s.hr_score,
    s.meanbp_score,
    s.temp_score,
    s.resprate_score,
    s.pao2_aado2_score,
    s.hematocrit_score,
    s.wbc_score,
    s.creatinine_score,
    s.sodium_score,
    s.potassium_score,
    s.acidbase_score,
    s.gcs_score
   FROM (mimiciii.icustays ie
     LEFT JOIN score s ON ((ie.icustay_id = s.icustay_id)))
  ORDER BY ie.icustay_id;
