create function round(numeric) returns numeric
IMMUTABLE
LANGUAGE SQL
AS $$
select pg_catalog.round($1,0)
$$;
