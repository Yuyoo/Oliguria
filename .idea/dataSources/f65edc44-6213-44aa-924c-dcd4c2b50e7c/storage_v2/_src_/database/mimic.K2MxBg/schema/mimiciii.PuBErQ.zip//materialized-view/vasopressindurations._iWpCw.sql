CREATE MATERIALIZED VIEW vasopressindurations AS WITH vasocv1 AS (
         SELECT inputevents_cv.icustay_id,
            inputevents_cv.charttime,
            max(
                CASE
                    WHEN (inputevents_cv.itemid = 30051) THEN 1
                    ELSE 0
                END) AS vaso,
            max(
                CASE
                    WHEN ((inputevents_cv.itemid = 30051) AND ((inputevents_cv.stopped)::text = ANY ((ARRAY['Stopped'::character varying, 'D/C''d'::character varying])::text[]))) THEN 1
                    ELSE 0
                END) AS vaso_stopped,
            max(
                CASE
                    WHEN ((inputevents_cv.itemid = 30051) AND (inputevents_cv.rate IS NOT NULL)) THEN 1
                    ELSE 0
                END) AS vaso_null,
            max(
                CASE
                    WHEN (inputevents_cv.itemid = 30051) THEN inputevents_cv.rate
                    ELSE NULL::double precision
                END) AS vaso_rate,
            max(
                CASE
                    WHEN (inputevents_cv.itemid = 30051) THEN inputevents_cv.amount
                    ELSE NULL::double precision
                END) AS vaso_amount
           FROM mimiciii.inputevents_cv
          WHERE (inputevents_cv.itemid = 30051)
          GROUP BY inputevents_cv.icustay_id, inputevents_cv.charttime
        ), vasocv2 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.vaso,
            v.vaso_stopped,
            v.vaso_null,
            v.vaso_rate,
            v.vaso_amount,
            sum(v.vaso_null) OVER (PARTITION BY v.icustay_id ORDER BY v.charttime) AS vaso_partition
           FROM vasocv1 v
        ), vasocv3 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.vaso,
            v.vaso_stopped,
            v.vaso_null,
            v.vaso_rate,
            v.vaso_amount,
            v.vaso_partition,
            first_value(v.vaso_rate) OVER (PARTITION BY v.icustay_id, v.vaso_partition ORDER BY v.charttime) AS vaso_prevrate_ifnull
           FROM vasocv2 v
        ), vasocv4 AS (
         SELECT vasocv3.icustay_id,
            vasocv3.charttime,
            vasocv3.vaso,
            vasocv3.vaso_rate,
            vasocv3.vaso_amount,
            vasocv3.vaso_stopped,
            vasocv3.vaso_prevrate_ifnull,
                CASE
                    WHEN (vasocv3.vaso = 0) THEN NULL::integer
                    WHEN ((vasocv3.vaso_rate > (0)::double precision) AND (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.vaso, vasocv3.vaso_null ORDER BY vasocv3.charttime) IS NULL)) THEN 1
                    WHEN ((vasocv3.vaso_rate = (0)::double precision) AND (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.vaso ORDER BY vasocv3.charttime) = (0)::double precision)) THEN 0
                    WHEN ((vasocv3.vaso_prevrate_ifnull = (0)::double precision) AND (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.vaso ORDER BY vasocv3.charttime) = (0)::double precision)) THEN 0
                    WHEN (lag(vasocv3.vaso_prevrate_ifnull, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.vaso ORDER BY vasocv3.charttime) = (0)::double precision) THEN 1
                    WHEN (lag(vasocv3.vaso_stopped, 1) OVER (PARTITION BY vasocv3.icustay_id, vasocv3.vaso ORDER BY vasocv3.charttime) = 1) THEN 1
                    ELSE NULL::integer
                END AS vaso_start
           FROM vasocv3
        ), vasocv5 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.vaso,
            v.vaso_rate,
            v.vaso_amount,
            v.vaso_stopped,
            v.vaso_prevrate_ifnull,
            v.vaso_start,
            sum(v.vaso_start) OVER (PARTITION BY v.icustay_id, v.vaso ORDER BY v.charttime) AS vaso_first
           FROM vasocv4 v
        ), vasocv6 AS (
         SELECT v.icustay_id,
            v.charttime,
            v.vaso,
            v.vaso_rate,
            v.vaso_amount,
            v.vaso_stopped,
            v.vaso_prevrate_ifnull,
            v.vaso_start,
            v.vaso_first,
                CASE
                    WHEN (v.vaso = 0) THEN NULL::bigint
                    WHEN (v.vaso_stopped = 1) THEN v.vaso_first
                    WHEN (v.vaso_rate = (0)::double precision) THEN v.vaso_first
                    WHEN (lead(v.charttime, 1) OVER (PARTITION BY v.icustay_id, v.vaso ORDER BY v.charttime) IS NULL) THEN v.vaso_first
                    ELSE NULL::bigint
                END AS vaso_stop
           FROM vasocv5 v
        ), vasocv AS (
         SELECT vasocv6.icustay_id,
            min(
                CASE
                    WHEN (vasocv6.vaso_rate IS NOT NULL) THEN vasocv6.charttime
                    ELSE NULL::timestamp without time zone
                END) AS starttime,
            min(
                CASE
                    WHEN (vasocv6.vaso_first = vasocv6.vaso_stop) THEN vasocv6.charttime
                    ELSE NULL::timestamp without time zone
                END) AS endtime
           FROM vasocv6
          WHERE ((vasocv6.vaso_first IS NOT NULL) AND (vasocv6.vaso_first <> 0) AND (vasocv6.icustay_id IS NOT NULL))
          GROUP BY vasocv6.icustay_id, vasocv6.vaso_first
         HAVING ((min(vasocv6.charttime) <> min(
                CASE
                    WHEN (vasocv6.vaso_first = vasocv6.vaso_stop) THEN vasocv6.charttime
                    ELSE NULL::timestamp without time zone
                END)) AND (max(vasocv6.vaso_rate) > (0)::double precision))
        ), vasomv AS (
         SELECT inputevents_mv.icustay_id,
            inputevents_mv.linkorderid,
            min(inputevents_mv.starttime) AS starttime,
            max(inputevents_mv.endtime) AS endtime
           FROM mimiciii.inputevents_mv
          WHERE ((inputevents_mv.itemid = 222315) AND ((inputevents_mv.statusdescription)::text <> 'Rewritten'::text))
          GROUP BY inputevents_mv.icustay_id, inputevents_mv.linkorderid
        )
 SELECT vasocv.icustay_id,
    row_number() OVER (PARTITION BY vasocv.icustay_id ORDER BY vasocv.starttime) AS vasonum,
    vasocv.starttime,
    vasocv.endtime,
    ((date_part('epoch'::text, (vasocv.endtime - vasocv.starttime)) / (60)::double precision) / (60)::double precision) AS duration_hours
   FROM vasocv
UNION
 SELECT vasomv.icustay_id,
    row_number() OVER (PARTITION BY vasomv.icustay_id ORDER BY vasomv.starttime) AS vasonum,
    vasomv.starttime,
    vasomv.endtime,
    ((date_part('epoch'::text, (vasomv.endtime - vasomv.starttime)) / (60)::double precision) / (60)::double precision) AS duration_hours
   FROM vasomv
  ORDER BY 1, 2;

