CREATE MATERIALIZED VIEW ventdurations AS WITH vd0 AS (
         SELECT ventsettings.icustay_id,
                CASE
                    WHEN (ventsettings.mechvent = 1) THEN lag(ventsettings.charttime, 1) OVER (PARTITION BY ventsettings.icustay_id, ventsettings.mechvent ORDER BY ventsettings.charttime)
                    ELSE NULL::timestamp without time zone
                END AS charttime_lag,
            ventsettings.charttime,
            ventsettings.mechvent,
            ventsettings.oxygentherapy,
            ventsettings.extubated,
            ventsettings.selfextubated
           FROM mimiciii.ventsettings
        ), vd1 AS (
         SELECT ventsettings.icustay_id,
            ventsettings.charttime_lag,
            ventsettings.charttime,
            ventsettings.mechvent,
            ventsettings.oxygentherapy,
            ventsettings.extubated,
            ventsettings.selfextubated,
                CASE
                    WHEN (ventsettings.mechvent = 1) THEN (ventsettings.charttime - ventsettings.charttime_lag)
                    ELSE NULL::interval
                END AS ventduration,
            lag(ventsettings.extubated, 1) OVER (PARTITION BY ventsettings.icustay_id,
                CASE
                    WHEN ((ventsettings.mechvent = 1) OR (ventsettings.extubated = 1)) THEN 1
                    ELSE 0
                END ORDER BY ventsettings.charttime) AS extubatedlag,
                CASE
                    WHEN (lag(ventsettings.extubated, 1) OVER (PARTITION BY ventsettings.icustay_id,
                    CASE
                        WHEN ((ventsettings.mechvent = 1) OR (ventsettings.extubated = 1)) THEN 1
                        ELSE 0
                    END ORDER BY ventsettings.charttime) = 1) THEN 1
                    WHEN ((ventsettings.mechvent = 0) AND (ventsettings.oxygentherapy = 1)) THEN 1
                    WHEN ((ventsettings.charttime - ventsettings.charttime_lag) > '08:00:00'::interval hour) THEN 1
                    ELSE 0
                END AS newvent
           FROM vd0 ventsettings
        ), vd2 AS (
         SELECT vd1.icustay_id,
            vd1.charttime_lag,
            vd1.charttime,
            vd1.mechvent,
            vd1.oxygentherapy,
            vd1.extubated,
            vd1.selfextubated,
            vd1.ventduration,
            vd1.extubatedlag,
            vd1.newvent,
                CASE
                    WHEN ((vd1.mechvent = 1) OR (vd1.extubated = 1)) THEN sum(vd1.newvent) OVER (PARTITION BY vd1.icustay_id ORDER BY vd1.charttime)
                    ELSE NULL::bigint
                END AS ventnum
           FROM vd1
        )
 SELECT vd2.icustay_id,
    row_number() OVER (PARTITION BY vd2.icustay_id ORDER BY vd2.ventnum) AS ventnum,
    min(vd2.charttime) AS starttime,
    max(vd2.charttime) AS endtime,
    ((date_part('epoch'::text, (max(vd2.charttime) - min(vd2.charttime))) / (60)::double precision) / (60)::double precision) AS duration_hours
   FROM vd2
  GROUP BY vd2.icustay_id, vd2.ventnum
 HAVING ((min(vd2.charttime) <> max(vd2.charttime)) AND (max(vd2.mechvent) = 1))
  ORDER BY vd2.icustay_id, (row_number() OVER (PARTITION BY vd2.icustay_id ORDER BY vd2.ventnum));

