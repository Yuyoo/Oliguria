CREATE MATERIALIZED VIEW inout_day AS WITH t3 AS (
         SELECT t2.subject_id,
            t2.hadm_id,
            t2.icustay_id,
            t2.chart_date,
            ((t1.sum)::double precision - t2.sum) AS in_out
           FROM mimiciii.input_day t1,
            mimiciii.output_day t2
          WHERE ((t1.chart_date = t2.chart_date) AND (t1.icustay_id = t2.icustay_id))
        )
 SELECT t3.subject_id,
    t3.hadm_id,
    t3.icustay_id,
    t3.chart_date,
    t3.in_out
   FROM t3
  GROUP BY t3.subject_id, t3.hadm_id, t3.icustay_id, t3.chart_date, t3.in_out;
