CREATE MATERIALIZED VIEW ventsettings AS SELECT ce.icustay_id,
    ce.charttime,
    max(
        CASE
            WHEN ((ce.itemid IS NULL) OR (ce.value IS NULL)) THEN 0
            WHEN ((ce.itemid = 720) AND ((ce.value)::text <> 'Other/Remarks'::text)) THEN 1
            WHEN ((ce.itemid = 223848) AND ((ce.value)::text <> 'Other'::text)) THEN 1
            WHEN (ce.itemid = 223849) THEN 1
            WHEN ((ce.itemid = 467) AND ((ce.value)::text = 'Ventilator'::text)) THEN 1
            WHEN (ce.itemid = ANY (ARRAY[445, 448, 449, 450, 1340, 1486, 1600, 224687, 639, 654, 681, 682, 683, 684, 224685, 224684, 224686, 218, 436, 535, 444, 459, 224697, 224695, 224696, 224746, 224747, 221, 1, 1211, 1655, 2000, 226873, 224738, 224419, 224750, 227187, 543, 5865, 5866, 224707, 224709, 224705, 224706, 60, 437, 505, 506, 686, 220339, 224700, 3459, 501, 502, 503, 224702, 223, 667, 668, 669, 670, 671, 672, 224701])) THEN 1
            ELSE 0
        END) AS mechvent,
    max(
        CASE
            WHEN ((ce.itemid = 226732) AND ((ce.value)::text = ANY ((ARRAY['Nasal cannula'::character varying, 'Face tent'::character varying, 'Aerosol-cool'::character varying, 'Trach mask '::character varying, 'High flow neb'::character varying, 'Non-rebreather'::character varying, 'Venti mask '::character varying, 'Medium conc mask '::character varying, 'T-piece'::character varying, 'High flow nasal cannula'::character varying, 'Ultrasonic neb'::character varying, 'Vapomist'::character varying])::text[]))) THEN 1
            WHEN ((ce.itemid = 467) AND ((ce.value)::text = ANY ((ARRAY['Cannula'::character varying, 'Nasal Cannula'::character varying, 'None'::character varying, 'Face Tent'::character varying, 'Aerosol-Cool'::character varying, 'Trach Mask'::character varying, 'Hi Flow Neb'::character varying, 'Non-Rebreather'::character varying, 'Venti Mask'::character varying, 'Medium Conc Mask'::character varying, 'Vapotherm'::character varying, 'T-Piece'::character varying, 'Hood'::character varying, 'Hut'::character varying, 'TranstrachealCat'::character varying, 'Heated Neb'::character varying, 'Ultrasonic Neb'::character varying])::text[]))) THEN 1
            ELSE 0
        END) AS oxygentherapy,
    max(
        CASE
            WHEN ((ce.itemid IS NULL) OR (ce.value IS NULL)) THEN 0
            WHEN ((ce.itemid = 640) AND ((ce.value)::text = 'Extubated'::text)) THEN 1
            WHEN ((ce.itemid = 640) AND ((ce.value)::text = 'Self Extubation'::text)) THEN 1
            ELSE 0
        END) AS extubated,
    max(
        CASE
            WHEN ((ce.itemid IS NULL) OR (ce.value IS NULL)) THEN 0
            WHEN ((ce.itemid = 640) AND ((ce.value)::text = 'Self Extubation'::text)) THEN 1
            ELSE 0
        END) AS selfextubated
   FROM mimiciii.chartevents ce
  WHERE ((ce.value IS NOT NULL) AND (ce.error IS DISTINCT FROM 1) AND (ce.itemid = ANY (ARRAY[720, 223849, 223848, 445, 448, 449, 450, 1340, 1486, 1600, 224687, 639, 654, 681, 682, 683, 684, 224685, 224684, 224686, 218, 436, 535, 444, 224697, 224695, 224696, 224746, 224747, 221, 1, 1211, 1655, 2000, 226873, 224738, 224419, 224750, 227187, 543, 5865, 5866, 224707, 224709, 224705, 224706, 60, 437, 505, 506, 686, 220339, 224700, 3459, 501, 502, 503, 224702, 223, 667, 668, 669, 670, 671, 672, 224701, 640, 468, 469, 470, 471, 227287, 226732, 223834, 467])))
  GROUP BY ce.icustay_id, ce.charttime
UNION
 SELECT procedureevents_mv.icustay_id,
    procedureevents_mv.starttime AS charttime,
    0 AS mechvent,
    0 AS oxygentherapy,
    1 AS extubated,
        CASE
            WHEN (procedureevents_mv.itemid = 225468) THEN 1
            ELSE 0
        END AS selfextubated
   FROM mimiciii.procedureevents_mv
  WHERE (procedureevents_mv.itemid = ANY (ARRAY[227194, 225468, 225477]));

