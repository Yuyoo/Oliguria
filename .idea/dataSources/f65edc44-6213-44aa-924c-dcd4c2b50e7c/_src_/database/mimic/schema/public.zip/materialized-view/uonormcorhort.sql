CREATE MATERIALIZED VIEW uonormcorhort AS WITH uo0 AS (
         SELECT icud.subject_id
           FROM mimiciii.icustay_detail icud
          WHERE ((icud.hospstay_seq = 1) AND (icud.icustay_seq = 1) AND (icud.los_icu > (1)::numeric))
        EXCEPT
         SELECT uos.subject_id
           FROM mimiciii.uofewcorhort uos
        )
 SELECT uo0.subject_id
   FROM uo0
  ORDER BY (random())
 LIMIT 3500;
