CREATE MATERIALIZED VIEW uofewcorhort AS WITH uo1 AS (
         SELECT DISTINCT icud.subject_id,
            icu.hadm_id,
            uo.icustay_id,
            min(uo.charttime) AS charttime
           FROM ((kdigo_uo uo
             JOIN mimiciii.icustays icu ON ((icu.icustay_id = uo.icustay_id)))
             JOIN mimiciii.icustay_detail icud ON ((icu.icustay_id = icud.icustay_id)))
          WHERE ((uo.urineoutput_24hr < (400)::double precision) AND (round(((date_part('epoch'::text, (uo.charttime - icu.intime)) / (((60 * 60) * 24))::double precision))::numeric, 4) > (1)::numeric) AND (round(((date_part('epoch'::text, (icu.outtime - uo.charttime)) / (((60 * 60) * 24))::double precision))::numeric, 4) > (1)::numeric) AND (icud.icustay_seq = 1) AND (icud.hospstay_seq = 1))
          GROUP BY icud.subject_id, icu.hadm_id, uo.icustay_id
        ), uo2 AS (
         SELECT uo1.subject_id,
            uo1.hadm_id,
            uo1.icustay_id,
            uo1.charttime,
            uo.weight,
            uo.urineoutput_24hr
           FROM (uo1
             JOIN kdigo_uo uo ON (((uo.icustay_id = uo1.icustay_id) AND (uo1.charttime = uo.charttime))))
        ), ct1 AS (
         SELECT le.subject_id,
            le.hadm_id,
            le.itemid,
            min(le.charttime) AS charttime
           FROM mimiciii.labevents le
          WHERE (le.itemid = 50912)
          GROUP BY le.subject_id, le.hadm_id, le.itemid
        ), ct2 AS (
         SELECT le.row_id,
            le.subject_id,
            le.hadm_id,
            le.itemid,
            le.charttime,
            le.value,
            le.valuenum,
            le.valueuom,
            le.flag
           FROM (ct1
             JOIN mimiciii.labevents le ON (((ct1.charttime = le.charttime) AND (ct1.itemid = le.itemid))))
          WHERE (le.valuenum < (4)::double precision)
        )
 SELECT uo2.subject_id,
    uo2.hadm_id,
    uo2.icustay_id,
    uo2.charttime,
    uo2.weight,
    uo2.urineoutput_24hr
   FROM (ct2
     JOIN uo2 ON ((ct2.hadm_id = uo2.hadm_id)));
