CREATE MATERIALIZED VIEW bloodgasfirstday AS SELECT pvt.subject_id,
    pvt.hadm_id,
    pvt.icustay_id,
    pvt.charttime,
    max((
        CASE
            WHEN (pvt.label = 'SPECIMEN'::text) THEN pvt.value
            ELSE NULL::character varying
        END)::text) AS specimen,
    max(
        CASE
            WHEN (pvt.label = 'AADO2'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS aado2,
    max(
        CASE
            WHEN (pvt.label = 'BASEEXCESS'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS baseexcess,
    max(
        CASE
            WHEN (pvt.label = 'BICARBONATE'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS bicarbonate,
    max(
        CASE
            WHEN (pvt.label = 'TOTALCO2'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS totalco2,
    max(
        CASE
            WHEN (pvt.label = 'CARBOXYHEMOGLOBIN'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS carboxyhemoglobin,
    max(
        CASE
            WHEN (pvt.label = 'CHLORIDE'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS chloride,
    max(
        CASE
            WHEN (pvt.label = 'CALCIUM'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS calcium,
    max(
        CASE
            WHEN (pvt.label = 'GLUCOSE'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS glucose,
    max(
        CASE
            WHEN (pvt.label = 'HEMATOCRIT'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS hematocrit,
    max(
        CASE
            WHEN (pvt.label = 'HEMOGLOBIN'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS hemoglobin,
    max(
        CASE
            WHEN (pvt.label = 'INTUBATED'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS intubated,
    max(
        CASE
            WHEN (pvt.label = 'LACTATE'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS lactate,
    max(
        CASE
            WHEN (pvt.label = 'METHEMOGLOBIN'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS methemoglobin,
    max(
        CASE
            WHEN (pvt.label = 'O2FLOW'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS o2flow,
    max(
        CASE
            WHEN (pvt.label = 'FIO2'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS fio2,
    max(
        CASE
            WHEN (pvt.label = 'SO2'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS so2,
    max(
        CASE
            WHEN (pvt.label = 'PCO2'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS pco2,
    max(
        CASE
            WHEN (pvt.label = 'PEEP'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS peep,
    max(
        CASE
            WHEN (pvt.label = 'PH'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS ph,
    max(
        CASE
            WHEN (pvt.label = 'PO2'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS po2,
    max(
        CASE
            WHEN (pvt.label = 'POTASSIUM'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS potassium,
    max(
        CASE
            WHEN (pvt.label = 'REQUIREDO2'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS requiredo2,
    max(
        CASE
            WHEN (pvt.label = 'SODIUM'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS sodium,
    max(
        CASE
            WHEN (pvt.label = 'TEMPERATURE'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS temperature,
    max(
        CASE
            WHEN (pvt.label = 'TIDALVOLUME'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS tidalvolume,
    max(
        CASE
            WHEN (pvt.label = 'VENTILATIONRATE'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS ventilationrate,
    max(
        CASE
            WHEN (pvt.label = 'VENTILATOR'::text) THEN pvt.valuenum
            ELSE NULL::double precision
        END) AS ventilator
   FROM ( SELECT ie.subject_id,
            ie.hadm_id,
            ie.icustay_id,
                CASE
                    WHEN (le.itemid = 50800) THEN 'SPECIMEN'::text
                    WHEN (le.itemid = 50801) THEN 'AADO2'::text
                    WHEN (le.itemid = 50802) THEN 'BASEEXCESS'::text
                    WHEN (le.itemid = 50803) THEN 'BICARBONATE'::text
                    WHEN (le.itemid = 50804) THEN 'TOTALCO2'::text
                    WHEN (le.itemid = 50805) THEN 'CARBOXYHEMOGLOBIN'::text
                    WHEN (le.itemid = 50806) THEN 'CHLORIDE'::text
                    WHEN (le.itemid = 50808) THEN 'CALCIUM'::text
                    WHEN (le.itemid = 50809) THEN 'GLUCOSE'::text
                    WHEN (le.itemid = 50810) THEN 'HEMATOCRIT'::text
                    WHEN (le.itemid = 50811) THEN 'HEMOGLOBIN'::text
                    WHEN (le.itemid = 50812) THEN 'INTUBATED'::text
                    WHEN (le.itemid = 50813) THEN 'LACTATE'::text
                    WHEN (le.itemid = 50814) THEN 'METHEMOGLOBIN'::text
                    WHEN (le.itemid = 50815) THEN 'O2FLOW'::text
                    WHEN (le.itemid = 50816) THEN 'FIO2'::text
                    WHEN (le.itemid = 50817) THEN 'SO2'::text
                    WHEN (le.itemid = 50818) THEN 'PCO2'::text
                    WHEN (le.itemid = 50819) THEN 'PEEP'::text
                    WHEN (le.itemid = 50820) THEN 'PH'::text
                    WHEN (le.itemid = 50821) THEN 'PO2'::text
                    WHEN (le.itemid = 50822) THEN 'POTASSIUM'::text
                    WHEN (le.itemid = 50823) THEN 'REQUIREDO2'::text
                    WHEN (le.itemid = 50824) THEN 'SODIUM'::text
                    WHEN (le.itemid = 50825) THEN 'TEMPERATURE'::text
                    WHEN (le.itemid = 50826) THEN 'TIDALVOLUME'::text
                    WHEN (le.itemid = 50827) THEN 'VENTILATIONRATE'::text
                    WHEN (le.itemid = 50828) THEN 'VENTILATOR'::text
                    ELSE NULL::text
                END AS label,
            le.charttime,
            le.value,
                CASE
                    WHEN (le.valuenum <= (0)::double precision) THEN NULL::double precision
                    WHEN ((le.itemid = 50810) AND (le.valuenum > (100)::double precision)) THEN NULL::double precision
                    WHEN ((le.itemid = 50816) AND (le.valuenum > (100)::double precision)) THEN NULL::double precision
                    WHEN ((le.itemid = 50817) AND (le.valuenum > (100)::double precision)) THEN NULL::double precision
                    WHEN ((le.itemid = 50815) AND (le.valuenum > (70)::double precision)) THEN NULL::double precision
                    WHEN ((le.itemid = 50821) AND (le.valuenum > (800)::double precision)) THEN NULL::double precision
                    ELSE le.valuenum
                END AS valuenum
           FROM (mimiciii.icustays ie
             LEFT JOIN mimiciii.labevents le ON (((le.subject_id = ie.subject_id) AND (le.hadm_id = ie.hadm_id) AND ((le.charttime >= (ie.intime - '06:00:00'::interval hour)) AND (le.charttime <= (ie.intime + '1 day'::interval day))) AND (le.itemid = ANY (ARRAY[50800, 50801, 50802, 50803, 50804, 50805, 50806, 50807, 50808, 50809, 50810, 50811, 50812, 50813, 50814, 50815, 50816, 50817, 50818, 50819, 50820, 50821, 50822, 50823, 50824, 50825, 50826, 50827, 50828, 51545])))))) pvt
  GROUP BY pvt.subject_id, pvt.hadm_id, pvt.icustay_id, pvt.charttime
  ORDER BY pvt.subject_id, pvt.hadm_id, pvt.icustay_id, pvt.charttime;
