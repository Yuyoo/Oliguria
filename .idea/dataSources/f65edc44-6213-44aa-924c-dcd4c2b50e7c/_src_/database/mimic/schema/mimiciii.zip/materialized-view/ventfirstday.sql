CREATE MATERIALIZED VIEW ventfirstday AS SELECT tt.subject_id,
    tt.hadm_id,
    tt.icustay_id,
    max(
        CASE
            WHEN (tt.value IS NULL) THEN 0
            WHEN ((((((((((((((tt.venttyperecorded + tt.minutevolume) + tt.tv) + tt.insppressure) + tt.plateaupressure) + tt.aprvpressure) + tt.peep) + tt.highpressurerelease) + tt.pcv) + tt.tcpcv) + tt.resppressure) + tt.psvlevel) + tt.ett) + tt.o2fromventilator) > 0) THEN 1
            ELSE 0
        END) AS mechvent
   FROM ( SELECT ie.subject_id,
            ie.icustay_id,
            ie.hadm_id,
            ce.charttime,
            ce.itemid,
            di.label,
            ce.value,
                CASE
                    WHEN ((ce.itemid = 720) AND ((ce.value)::text <> 'Other/Remarks'::text)) THEN 1
                    ELSE 0
                END AS venttyperecorded,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[445, 448, 449, 450, 1340, 1486, 1600, 224687])) THEN 1
                    ELSE 0
                END AS minutevolume,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[639, 654, 681, 682, 683, 684, 224685, 224684, 224686])) THEN 1
                    ELSE 0
                END AS tv,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[218, 436, 535, 444, 459, 224697, 224695, 224696, 224746, 224747])) THEN 1
                    ELSE 0
                END AS resppressure,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[221, 1, 1211, 1655, 2000, 226873, 224738, 224419, 224750, 227187])) THEN 1
                    ELSE 0
                END AS insppressure,
                CASE
                    WHEN (ce.itemid = 543) THEN 1
                    ELSE 0
                END AS plateaupressure,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[5865, 5866, 224707, 224709, 224705, 224706])) THEN 1
                    ELSE 0
                END AS aprvpressure,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[60, 437, 505, 506, 686, 220339, 224700])) THEN 1
                    ELSE 0
                END AS peep,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[141, 224417, 224418])) THEN 1
                    ELSE 0
                END AS cuffpressure,
                CASE
                    WHEN (ce.itemid = 3459) THEN 1
                    ELSE 0
                END AS highpressurerelease,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[501, 502, 503, 224702])) THEN 1
                    ELSE 0
                END AS pcv,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[223, 667, 668, 669, 670, 671, 672])) THEN 1
                    ELSE 0
                END AS tcpcv,
                CASE
                    WHEN ((ce.itemid = 467) AND ((ce.value)::text = 'Ventilator'::text)) THEN 1
                    ELSE 0
                END AS o2fromventilator,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[578, 3605])) THEN 1
                    ELSE 0
                END AS pressuresupport,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[3688, 3689])) THEN 1
                    ELSE 0
                END AS vtinches,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[63, 64, 65, 66, 67, 68, 227579, 227580, 227582, 227581])) THEN 1
                    ELSE 0
                END AS bipap,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[157, 158, 1852, 3398, 3399, 3400, 3401, 3402, 3403, 3404, 8382, 227809, 227810])) THEN 1
                    ELSE 0
                END AS ett,
                CASE
                    WHEN (ce.itemid = 224701) THEN 1
                    ELSE 0
                END AS psvlevel,
                CASE
                    WHEN (ce.itemid = 223835) THEN 1
                    ELSE 0
                END AS fio2,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[614, 615, 619, 653, 224688, 224690, 224689])) THEN 1
                    ELSE 0
                END AS resprate,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[194, 195, 224691])) THEN 1
                    ELSE 0
                END AS flowby,
                CASE
                    WHEN (ce.itemid = ANY (ARRAY[470, 471, 223834, 227287])) THEN 1
                    ELSE 0
                END AS o2flow,
                CASE
                    WHEN ((ce.itemid = 648) AND ((ce.value)::text = 'Intubated/trach'::text)) THEN 1
                    ELSE 0
                END AS speechintubated
           FROM ((mimiciii.icustays ie
             LEFT JOIN mimiciii.chartevents ce ON (((ie.icustay_id = ce.icustay_id) AND (ce.value IS NOT NULL) AND ((ce.charttime >= ie.intime) AND (ce.charttime <= (ie.intime + '1 day'::interval day))))))
             LEFT JOIN mimiciii.d_items di ON ((ce.itemid = di.itemid)))) tt
  GROUP BY tt.subject_id, tt.hadm_id, tt.icustay_id
  ORDER BY tt.subject_id, tt.hadm_id, tt.icustay_id;
