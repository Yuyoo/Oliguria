CREATE MATERIALIZED VIEW weightdurations AS WITH wt_stg AS (
         SELECT c.icustay_id,
            c.charttime,
                CASE
                    WHEN (c.itemid = ANY (ARRAY[762, 226512])) THEN 'admit'::text
                    ELSE 'daily'::text
                END AS weight_type,
            c.valuenum AS weight
           FROM mimiciii.chartevents c
          WHERE ((c.valuenum IS NOT NULL) AND (c.itemid = ANY (ARRAY[762, 226512, 763, 224639])) AND (c.valuenum <> (0)::double precision) AND (c.error IS DISTINCT FROM 1))
        ), wt_stg1 AS (
         SELECT wt_stg.icustay_id,
            wt_stg.charttime,
            wt_stg.weight_type,
            wt_stg.weight,
            row_number() OVER (PARTITION BY wt_stg.icustay_id, wt_stg.weight_type ORDER BY wt_stg.charttime) AS rn
           FROM wt_stg
        ), wt_stg2 AS (
         SELECT wt_stg1.icustay_id,
            ie.intime,
            ie.outtime,
                CASE
                    WHEN ((wt_stg1.weight_type = 'admit'::text) AND (wt_stg1.rn = 1)) THEN (ie.intime - '02:00:00'::interval hour)
                    ELSE wt_stg1.charttime
                END AS starttime,
            wt_stg1.weight
           FROM (mimiciii.icustays ie
             JOIN wt_stg1 ON ((ie.icustay_id = wt_stg1.icustay_id)))
          WHERE (NOT ((wt_stg1.weight_type = 'admit'::text) AND (wt_stg1.rn = 1)))
        ), wt_stg3 AS (
         SELECT wt_stg2.icustay_id,
            wt_stg2.starttime,
            COALESCE(lead(wt_stg2.starttime) OVER (PARTITION BY wt_stg2.icustay_id ORDER BY wt_stg2.starttime), (wt_stg2.outtime + '02:00:00'::interval hour)) AS endtime,
            wt_stg2.weight
           FROM wt_stg2
        ), wt1 AS (
         SELECT ie.icustay_id,
            wt.starttime,
                CASE
                    WHEN (wt.icustay_id IS NULL) THEN NULL::timestamp without time zone
                    ELSE COALESCE(wt.endtime, lead(wt.starttime) OVER (PARTITION BY ie.icustay_id ORDER BY wt.starttime), (ie.outtime + '02:00:00'::interval hour))
                END AS endtime,
            wt.weight
           FROM (mimiciii.icustays ie
             LEFT JOIN wt_stg3 wt ON ((ie.icustay_id = wt.icustay_id)))
        ), wt_fix AS (
         SELECT ie.icustay_id,
            (ie.intime - '02:00:00'::interval hour) AS starttime,
            wt.starttime AS endtime,
            wt.weight
           FROM (mimiciii.icustays ie
             JOIN ( SELECT wt1.icustay_id,
                    wt1.starttime,
                    wt1.weight
                   FROM (wt1
                     JOIN ( SELECT wt1_1.icustay_id,
                            min(wt1_1.starttime) AS starttime
                           FROM wt1 wt1_1
                          GROUP BY wt1_1.icustay_id) wt2 ON (((wt1.icustay_id = wt2.icustay_id) AND (wt1.starttime = wt2.starttime))))) wt ON (((ie.icustay_id = wt.icustay_id) AND (ie.intime < wt.starttime))))
        ), wt2 AS (
         SELECT wt1.icustay_id,
            wt1.starttime,
            wt1.endtime,
            wt1.weight
           FROM wt1
        UNION
         SELECT wt_fix.icustay_id,
            wt_fix.starttime,
            wt_fix.endtime,
            wt_fix.weight
           FROM wt_fix
        ), echo_lag AS (
         SELECT ie.icustay_id,
            ie.intime,
            ie.outtime,
            (0.453592 * ec.weight) AS weight_echo,
            row_number() OVER (PARTITION BY ie.icustay_id ORDER BY ec.charttime) AS rn,
            ec.charttime AS starttime,
            lead(ec.charttime) OVER (PARTITION BY ie.icustay_id ORDER BY ec.charttime) AS endtime
           FROM (mimiciii.icustays ie
             JOIN mimiciii.echodata ec ON ((ie.hadm_id = ec.hadm_id)))
          WHERE (ec.weight IS NOT NULL)
        ), echo_final AS (
         SELECT el.icustay_id,
            el.starttime,
            COALESCE(el.endtime, (el.outtime + '02:00:00'::interval hour)) AS endtime,
            el.weight_echo
           FROM echo_lag el
        UNION
         SELECT el.icustay_id,
            (el.intime - '02:00:00'::interval hour) AS starttime,
            el.starttime AS endtime,
            el.weight_echo
           FROM echo_lag el
          WHERE ((el.rn = 1) AND (el.starttime > (el.intime - '02:00:00'::interval hour)))
        )
 SELECT wt2.icustay_id,
    wt2.starttime,
    wt2.endtime,
    wt2.weight
   FROM wt2
UNION
 SELECT ef.icustay_id,
    ef.starttime,
    ef.endtime,
    ef.weight_echo AS weight
   FROM echo_final ef
  WHERE (NOT (ef.icustay_id IN ( SELECT DISTINCT wt2.icustay_id
           FROM wt2)))
  ORDER BY 1, 2, 3;
