CREATE MATERIALIZED VIEW input_day AS WITH tmp AS (
         SELECT o.subject_id,
            o.hadm_id,
            o.icustay_id,
            (o.charttime)::date AS chart_date,
            o.amount,
            o.amountuom
           FROM mimiciii.inputevents_cv o
        )
 SELECT tmp.subject_id,
    tmp.hadm_id,
    tmp.icustay_id,
    tmp.chart_date,
    sum((tmp.amount)::numeric) AS sum
   FROM tmp
  WHERE (((tmp.amountuom)::text = 'cc'::text) OR ((tmp.amountuom)::text = 'ml'::text))
  GROUP BY tmp.subject_id, tmp.hadm_id, tmp.icustay_id, tmp.chart_date;
